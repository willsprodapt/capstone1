// Theme toggle + shared toast helper (loaded on every page).
(function () {
  const root = document.documentElement;
  const btn = document.getElementById('themeToggle');

  function isDark() {
    const forced = root.getAttribute('data-theme');
    if (forced) return forced === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function syncIcon() {
    if (!btn) return;
    const icon = btn.querySelector('i');
    icon.className = 'ph ' + (isDark() ? 'ph-sun' : 'ph-moon');
    btn.setAttribute('aria-label', isDark() ? 'Switch to light theme' : 'Switch to dark theme');
  }

  if (btn) {
    btn.addEventListener('click', () => {
      const next = isDark() ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('theme', next); } catch (e) {}
      syncIcon();
    });
  }
  syncIcon();

  let toastTimer = null;
  window.showToast = function (message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('is-visible'), 3200);
  };
})();
