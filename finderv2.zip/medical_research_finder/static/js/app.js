// State
let currentMode = 'fetch'; // 'fetch' or 'chat'
let fetchedPapers = [];
let selectedPapersMap = new Map(); // pmid -> paper object
let conversationHistory = [];

document.addEventListener('DOMContentLoaded', () => {
  const chatInput = document.getElementById('chatInput');

  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        submitChatMessage();
      }
    });
    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  renderActiveContext();
  // Load the default query on first visit
  performFetch();
});

// ==========================================
// MODE NAVIGATION
// ==========================================
function switchMode(mode) {
  currentMode = mode;
  const tabFetch = document.getElementById('tabFetchMode');
  const tabChat = document.getElementById('tabChatMode');
  const isFetch = mode === 'fetch';

  tabFetch.classList.toggle('active', isFetch);
  tabChat.classList.toggle('active', !isFetch);
  tabFetch.setAttribute('aria-selected', String(isFetch));
  tabChat.setAttribute('aria-selected', String(!isFetch));
  document.getElementById('fetchSection').classList.toggle('hidden', !isFetch);
  document.getElementById('chatSection').classList.toggle('hidden', isFetch);

  if (!isFetch) {
    renderActiveContext();
    scrollToBottom();
  }
  updateSelectionBadges();
}

// ==========================================
// PAPERS: SEARCH AND BROWSE
// ==========================================
function setFetchQuery(text) {
  const input = document.getElementById('fetchQueryInput');
  if (input) {
    input.value = text;
    performFetch();
  }
}

function renderSkeletons(count) {
  return Array.from({ length: count }, () => `
    <div class="skeleton-row" aria-hidden="true">
      <div class="sk w-70"></div>
      <div class="sk w-40"></div>
      <div class="sk w-90"></div>
      <div class="sk w-90"></div>
    </div>
  `).join('');
}

async function performFetch() {
  const query = document.getElementById('fetchQueryInput').value.trim();
  if (!query) return;

  const btn = document.getElementById('fetchBtn');
  const btnText = document.getElementById('fetchBtnText');
  const spinner = document.getElementById('fetchSpinner');
  const errorBanner = document.getElementById('fetchErrorBanner');
  const container = document.getElementById('fetchedResultsContainer');
  const list = document.getElementById('fetchedPapersList');

  const mode = document.getElementById('fetchMode').value;
  const topK = parseInt(document.getElementById('fetchTopK').value, 10);
  const minYear = document.getElementById('fetchMinYear').value ? parseInt(document.getElementById('fetchMinYear').value, 10) : null;
  const keywordFilter = document.getElementById('fetchKeywordFilter').value.trim() || null;

  btn.disabled = true;
  btnText.textContent = 'Searching';
  spinner.classList.remove('hidden');
  errorBanner.classList.add('hidden');

  // Skeleton placeholders shaped like the final rows
  list.innerHTML = renderSkeletons(Math.min(topK, 4));
  container.classList.remove('hidden');

  try {
    const res = await fetch('/api/fetch_papers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: query,
        mode: mode,
        top_k: topK,
        min_year: minYear,
        keyword_filter: keywordFilter,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'The search could not be completed');
    }

    const data = await res.json();
    fetchedPapers = data.papers || [];

    // Start with the top three selected so "Ask" works immediately
    selectedPapersMap.clear();
    fetchedPapers.slice(0, 3).forEach(p => selectedPapersMap.set(p.pmid, p));

    renderFetchedPapers();
    updateSelectionBadges();
  } catch (err) {
    fetchedPapers = [];
    container.classList.add('hidden');
    errorBanner.innerHTML = `<i class="ph ph-warning-circle" aria-hidden="true"></i><span>${escapeHtml(err.message)}</span>`;
    errorBanner.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btnText.textContent = 'Search';
    spinner.classList.add('hidden');
  }
}

function renderFetchedPapers() {
  const list = document.getElementById('fetchedPapersList');
  document.getElementById('fetchedCount').textContent = fetchedPapers.length;

  if (fetchedPapers.length === 0) {
    list.innerHTML = `
      <div class="empty">
        <i class="ph ph-file-magnifying-glass" aria-hidden="true"></i>
        <strong>No matching papers</strong>
        <p>Try broader wording, remove the year or topic filter, or switch retrieval mode.</p>
      </div>`;
    return;
  }

  list.innerHTML = fetchedPapers.map((p, idx) => {
    const isSelected = selectedPapersMap.has(p.pmid);
    return `
      <article class="paper reveal ${isSelected ? 'selected' : ''}" id="card_${p.pmid}" style="--i:${idx}">
        <input type="checkbox" class="check" aria-label="Select paper ${escapeHtml(p.pmid)}"
               ${isSelected ? 'checked' : ''} onchange="togglePaperSelection('${p.pmid}', this.checked)">
        <div class="paper-body">
          <button class="paper-title" onclick="openPaperModal('${p.pmid}')">${escapeHtml(p.title)}</button>
          <div class="paper-meta">
            <span>${escapeHtml(p.publication_date || 'Date unknown')}</span>
            <span class="pmid">PMID ${escapeHtml(p.pmid)}</span>
            <span class="authors" title="${escapeHtml(p.authors || '')}">${escapeHtml(p.authors || 'Authors unknown')}</span>
          </div>
          <p class="paper-snippet">${escapeHtml(p.abstract)}</p>
          <div class="paper-foot">
            <div class="scores">
              <span title="Reciprocal rank fusion score">RRF ${escapeHtml(String(p.rrf_score))}</span>
              <span title="Dense cosine similarity">Dense ${escapeHtml(String(p.dense_score))}</span>
            </div>
            <div class="paper-actions">
              <button class="btn btn-ghost btn-sm" onclick="openPaperModal('${p.pmid}')">Abstract</button>
              <button class="btn btn-primary btn-sm" onclick="chatWithSinglePaper('${p.pmid}')">Ask this paper</button>
            </div>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function togglePaperSelection(pmid, checked) {
  const paper = fetchedPapers.find(p => p.pmid === pmid);
  if (checked && paper) {
    selectedPapersMap.set(pmid, paper);
  } else {
    selectedPapersMap.delete(pmid);
  }
  const card = document.getElementById(`card_${pmid}`);
  if (card) card.classList.toggle('selected', checked);
  updateSelectionBadges();
}

function selectAllPapers(selectAll) {
  if (selectAll) {
    fetchedPapers.forEach(p => selectedPapersMap.set(p.pmid, p));
  } else {
    selectedPapersMap.clear();
  }
  renderFetchedPapers();
  updateSelectionBadges();
}

function updateSelectionBadges() {
  const count = selectedPapersMap.size;
  document.getElementById('selectedCountBadge').textContent = count;
  document.getElementById('navContextBadge').textContent = count;
  const bar = document.getElementById('selectionBar');
  bar.classList.toggle('is-visible', currentMode === 'fetch' && count > 0);
}

function chatWithSinglePaper(pmid) {
  selectedPapersMap.clear();
  const paper = fetchedPapers.find(p => p.pmid === pmid);
  if (paper) selectedPapersMap.set(pmid, paper);
  switchMode('chat');
}

function proceedToChatWithSelected() {
  if (selectedPapersMap.size === 0) {
    showToast('Select at least one paper first.');
    return;
  }
  switchMode('chat');
}

// ==========================================
// ASK: GROUNDED Q&A
// ==========================================
function renderActiveContext() {
  const sidebarList = document.getElementById('activeContextPapersList');
  const countBadge = document.getElementById('activePapersCountBadge');
  const selectedList = Array.from(selectedPapersMap.values());
  countBadge.textContent = `${selectedList.length} ${selectedList.length === 1 ? 'paper' : 'papers'}`;

  if (selectedList.length === 0) {
    sidebarList.innerHTML = `
      <div class="empty">
        <i class="ph ph-books" aria-hidden="true"></i>
        <strong>Whole knowledge base</strong>
        <p>No papers picked. Questions will search all 2,000 indexed abstracts.</p>
      </div>`;
    return;
  }

  sidebarList.innerHTML = selectedList.map(p => `
    <div class="ctx-paper">
      <button class="paper-title" onclick="openPaperModal('${p.pmid}')">${escapeHtml(p.title)}</button>
      <div class="paper-meta">
        <span>${escapeHtml(p.publication_date || 'Date unknown')}</span>
        <span class="pmid">PMID ${escapeHtml(p.pmid)}</span>
      </div>
      <button class="ctx-remove" onclick="removeContextPaper('${p.pmid}')" aria-label="Remove paper ${escapeHtml(p.pmid)} from context">
        <i class="ph ph-x" aria-hidden="true"></i>
      </button>
    </div>
  `).join('');
}

function removeContextPaper(pmid) {
  selectedPapersMap.delete(pmid);
  updateSelectionBadges();
  renderActiveContext();
  const card = document.getElementById(`card_${pmid}`);
  if (card) {
    card.classList.remove('selected');
    const cb = card.querySelector('input[type="checkbox"]');
    if (cb) cb.checked = false;
  }
}

function clearSelectedContext() {
  selectedPapersMap.clear();
  updateSelectionBadges();
  renderActiveContext();
  renderFetchedPapers();
}

function sendChatPrompt(text) {
  const chatInput = document.getElementById('chatInput');
  if (chatInput) {
    chatInput.value = text;
    submitChatMessage();
  }
}

async function submitChatMessage() {
  const chatInput = document.getElementById('chatInput');
  const text = chatInput.value.trim();
  if (!text) return;

  const sendBtn = document.getElementById('sendBtn');
  const sendIcon = document.getElementById('sendIcon');
  const sendSpinner = document.getElementById('sendSpinner');

  chatInput.value = '';
  chatInput.style.height = 'auto';

  appendUserMessage(text);

  const indicatorId = 'indicator_' + Date.now();
  appendTypingIndicator(indicatorId);
  scrollToBottom();

  sendBtn.disabled = true;
  sendIcon.classList.add('hidden');
  sendSpinner.classList.remove('hidden');

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        selected_pmids: Array.from(selectedPapersMap.keys()),
        history: conversationHistory,
        top_k: 5,
        mode: 'hybrid',
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'The answer could not be generated');
    }

    const data = await res.json();
    removeElement(indicatorId);
    appendAssistantMessage(data);

    conversationHistory.push({ role: 'user', content: text });
    conversationHistory.push({ role: 'assistant', content: data.response });
  } catch (err) {
    removeElement(indicatorId);
    appendErrorMessage(err.message);
  } finally {
    sendBtn.disabled = false;
    sendIcon.classList.remove('hidden');
    sendSpinner.classList.add('hidden');
    scrollToBottom();
  }
}

function appendUserMessage(text) {
  const row = document.createElement('div');
  row.className = 'msg user';
  row.innerHTML = `
    <div class="msg-meta"><span class="who">You</span></div>
    <p>${escapeHtml(text)}</p>
  `;
  document.getElementById('chatMessages').appendChild(row);
}

function appendTypingIndicator(id) {
  const row = document.createElement('div');
  row.id = id;
  row.className = 'msg assistant';
  row.innerHTML = `
    <div class="typing">
      <span class="spinner" aria-hidden="true"></span>
      <span>Reading the papers</span>
    </div>
  `;
  document.getElementById('chatMessages').appendChild(row);
}

function appendAssistantMessage(data) {
  const grounding = data.grounding || {};
  const papers = data.retrieved_docs || [];

  let renderedHtml = marked.parse(data.response || '');

  // Clickable PMID citations
  renderedHtml = renderedHtml.replace(
    /\[(?:PMID:?\s*|pmid\s*)([0-9]+)\]/gi,
    (match, pmid) => `<a href="javascript:void(0)" onclick="openPaperModal('${pmid}')" class="pmid-badge">PMID ${pmid}</a>`
  );

  const score = grounding.grounding_score !== undefined ? grounding.grounding_score : 'n/a';
  const papersUsed = grounding.source_papers_used || 0;
  const verifiedCits = grounding.citations_verified || '0/0';
  const supportedPercent = Math.round((grounding.supported_claim_rate || 0) * 100);
  const isGrounded = (grounding.unsupported_claim_rate || 0) === 0;
  const claims = grounding.claims || [];

  const claimsHtml = claims.map(c => `
    <div class="claim ${c.supported ? '' : 'unsupported'}">
      <div>${escapeHtml(c.claim)}</div>
      <div class="claim-row">
        <span>${escapeHtml(String(c.citation))}</span>
        <span><code>${escapeHtml(String(c.evidence_score))}</code>
          <span class="badge ${c.supported ? 'badge-ok' : 'badge-bad'}">${c.supported ? 'Supported' : 'Unsupported'}</span>
        </span>
      </div>
      ${c.warning ? `<div class="claim-warn">${escapeHtml(String(c.warning))}</div>` : ''}
    </div>
  `).join('');

  const sourcesHtml = papers.map((p, i) => `
    <div class="source">
      <button onclick="openPaperModal('${p.pmid}')">${escapeHtml(p.title)}</button>
      <div class="sub">Doc ${i + 1} / PMID ${escapeHtml(String(p.pmid))} / ${escapeHtml(String(p.publication_date || ''))}</div>
    </div>
  `).join('');

  const row = document.createElement('div');
  row.className = 'msg assistant';
  row.innerHTML = `
    <div class="msg-meta">
      <span class="who">Research assistant</span>
      <span>${formatTime()}</span>
    </div>

    <div class="grounding">
      <span>Grounding <b>${escapeHtml(String(score))}</b></span>
      <span>Papers <b>${papersUsed}</b></span>
      <span>Citations <b>${escapeHtml(String(verifiedCits))}</b></span>
      <span>Supported <b>${supportedPercent}%</b></span>
      <span class="badge ${isGrounded ? 'badge-ok' : 'badge-warn'}">${isGrounded ? 'Verified' : 'Claims flagged'}</span>
    </div>

    ${isGrounded ? '' : `
      <div class="notice warn" style="margin-bottom: 16px;">
        <i class="ph ph-warning" aria-hidden="true"></i>
        <span>Some claims were not fully supported by the retrieved abstracts. Check them against the sources below.</span>
      </div>`}

    <div class="markdown-body">${renderedHtml}</div>

    <details class="evidence">
      <summary><i class="ph ph-caret-right" aria-hidden="true"></i> Evidence: ${claims.length} claims, ${papers.length} sources</summary>
      <div class="evidence-body">
        <div>
          <h4>Claim verification</h4>
          ${claimsHtml || '<p class="muted">No discrete claims were parsed.</p>'}
        </div>
        <div>
          <h4>Source papers</h4>
          ${sourcesHtml || '<p class="muted">No sources returned.</p>'}
        </div>
      </div>
    </details>
  `;
  document.getElementById('chatMessages').appendChild(row);
}

function appendErrorMessage(msg) {
  const row = document.createElement('div');
  row.className = 'msg assistant';
  row.innerHTML = `
    <div class="notice bad" role="alert">
      <i class="ph ph-warning-circle" aria-hidden="true"></i>
      <span>${escapeHtml(msg)}</span>
    </div>
  `;
  document.getElementById('chatMessages').appendChild(row);
}

// ==========================================
// PAPER MODAL
// ==========================================
async function openPaperModal(pmid) {
  try {
    const res = await fetch(`/api/paper/${pmid}`);
    if (!res.ok) {
      showToast(`PMID ${pmid} is not in the knowledge base.`);
      return;
    }
    const paper = await res.json();
    document.getElementById('modalTitle').textContent = paper.Title || 'Paper details';
    document.getElementById('modalPMID').textContent = paper.PMID || pmid;
    document.getElementById('modalDate').textContent = paper['Publication Date'] || 'Unknown';
    document.getElementById('modalAuthors').textContent = paper.Authors || 'Unknown';
    document.getElementById('modalMeSH').textContent = paper['MeSH Terms'] || 'None recorded';
    document.getElementById('modalKeywords').textContent = paper.Keywords || 'None recorded';
    document.getElementById('modalAbstract').textContent = paper.Abstract || 'No abstract available.';
    document.getElementById('paperModal').classList.remove('hidden');
  } catch (err) {
    console.error('Failed to open paper modal', err);
    showToast('Could not load that paper.');
  }
}

function closeModal() {
  const modal = document.getElementById('paperModal');
  if (modal) modal.classList.add('hidden');
}

// ==========================================
// HELPERS
// ==========================================
function scrollToBottom() {
  const chatMessages = document.getElementById('chatMessages');
  if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
}

function formatTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function removeElement(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function escapeHtml(text) {
  if (text === null || text === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}
