import json
import time
from pathlib import Path
import numpy as np

from src.config import CHUNKS_JSON, EMBEDDINGS_NPY
from src.gateway_client import gateway_client

CHECKPOINT_FILE = Path(__file__).resolve().parent / "data" / "embeddings_checkpoint.npy"

def build_embeddings():
    if EMBEDDINGS_NPY.exists():
        arr = np.load(EMBEDDINGS_NPY)
        print(f"Embeddings already exist at {EMBEDDINGS_NPY}. Shape: {arr.shape}")
        return

    print("Loading chunks from", CHUNKS_JSON)
    with open(CHUNKS_JSON, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    texts = [c["text"] for c in chunks]
    total = len(texts)
    print(f"Total texts to embed: {total}")

    all_embeddings = []
    start_idx = 0

    if CHECKPOINT_FILE.exists():
        try:
            cached = np.load(CHECKPOINT_FILE)
            if len(cached) > 0 and len(cached) <= total:
                all_embeddings = cached.tolist()
                start_idx = len(all_embeddings)
                print(f"Resuming from checkpoint: {start_idx}/{total} chunks already embedded.")
        except Exception as e:
            print("Checkpoint note:", e)

    batch_size = 40
    t0 = time.time()

    for i in range(start_idx, total, batch_size):
        batch = texts[i : i + batch_size]
        
        # Resilient batch execution with continuous retry
        batch_embs = None
        for retry in range(15):
            try:
                batch_embs = gateway_client.get_embeddings(batch, batch_size=batch_size)
                break
            except Exception as e:
                print(f"  [Warning] Batch at {i} failed attempt {retry+1}/15: {e}. Retrying in 4s...", flush=True)
                time.sleep(4.0)

        if batch_embs is None:
            raise RuntimeError(f"Failed to fetch embeddings for batch at {i} after 15 retries.")

        all_embeddings.extend(batch_embs)

        # Save checkpoint after every batch so progress is never lost
        np.save(CHECKPOINT_FILE, np.array(all_embeddings, dtype=np.float32))

        elapsed = time.time() - t0
        processed_this_run = len(all_embeddings) - start_idx
        rate = processed_this_run / max(elapsed, 0.001)
        remaining_items = total - len(all_embeddings)
        est_rem = remaining_items / max(rate, 0.001)

        print(
            f"  Progress: {len(all_embeddings)}/{total} ({len(all_embeddings)*100//total}%) | "
            f"Rate: {rate:.1f} chunks/s | Est. remaining: {est_rem:.1f}s",
            flush=True,
        )

    final_arr = np.array(all_embeddings, dtype=np.float32)
    np.save(EMBEDDINGS_NPY, final_arr)
    print(f"Successfully saved {final_arr.shape} embeddings to {EMBEDDINGS_NPY}!")

    if CHECKPOINT_FILE.exists():
        try:
            CHECKPOINT_FILE.unlink()
        except Exception:
            pass

if __name__ == "__main__":
    build_embeddings()
