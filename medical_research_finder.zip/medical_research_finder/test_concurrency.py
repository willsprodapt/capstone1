import concurrent.futures
import time
from src.gateway_client import gateway_client

def test_single_thread(batch_idx):
    texts = [f"Biomedical clinical test sentence {batch_idx}_{i}" for i in range(20)]
    t0 = time.time()
    res = gateway_client.get_embeddings(texts, batch_size=20)
    return len(res), time.time() - t0

def test_concurrent():
    print("Testing 3 concurrent threads...")
    t0 = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(test_single_thread, i) for i in range(3)]
        for f in concurrent.futures.as_completed(futures):
            count, dur = f.result()
            print(f"Worker completed {count} embeddings in {dur:.2f}s")
    print(f"Total concurrent time: {time.time()-t0:.2f}s")

if __name__ == "__main__":
    test_concurrent()
