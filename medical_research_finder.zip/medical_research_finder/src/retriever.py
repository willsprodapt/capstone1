import json
import re
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from rank_bm25 import BM25Okapi

from src.config import CHUNKS_JSON, EMBEDDINGS_NPY, RRF_K, DEFAULT_TOP_K
from src.gateway_client import gateway_client

class HybridRetriever:
    """
    Hybrid Retriever combining BM25 keyword search and Dense Vector retrieval,
    fused with Reciprocal Rank Fusion (RRF), cross-feature reranking, and metadata filtering.
    Supports graceful fallbacks (Dense-only -> BM25-only).
    """

    def __init__(self, chunks_path: Path = CHUNKS_JSON, embeddings_path: Path = EMBEDDINGS_NPY):
        self.chunks_path = chunks_path
        self.embeddings_path = embeddings_path
        self.chunks: List[Dict[str, Any]] = []
        self.embeddings: Optional[np.ndarray] = None
        self.bm25: Optional[BM25Okapi] = None
        self.tokenized_corpus: List[List[str]] = []
        self._is_indexed = False

    def tokenize(self, text: str) -> List[str]:
        """Simple, robust tokenization for BM25."""
        text = text.lower()
        tokens = re.findall(r"\b[a-z0-9\-]{2,}\b", text)
        return tokens

    def load_or_build_index(self, force_recompute_embeddings: bool = False):
        """Loads chunks, builds BM25 index, and loads or creates dense embeddings."""
        if not self.chunks_path.exists():
            raise FileNotFoundError(f"Chunks file not found at {self.chunks_path}. Run chunker first.")

        with open(self.chunks_path, "r", encoding="utf-8") as f:
            self.chunks = json.load(f)
        print(f"Retriever: Loaded {len(self.chunks)} chunks.")

        # Build BM25 index
        print("Retriever: Building BM25 index...")
        self.tokenized_corpus = [self.tokenize(c["text"]) for c in self.chunks]
        self.bm25 = BM25Okapi(self.tokenized_corpus)
        print("Retriever: BM25 index ready.")

        # Load or generate dense embeddings
        if self.embeddings_path.exists() and not force_recompute_embeddings:
            print(f"Retriever: Loading cached dense embeddings from {self.embeddings_path}...")
            self.embeddings = np.load(self.embeddings_path)
            # Normalize embeddings for cosine similarity via dot product
            norms = np.linalg.norm(self.embeddings, axis=1, keepdims=True)
            norms[norms == 0] = 1e-9
            self.embeddings = self.embeddings / norms
            print(f"Retriever: Loaded embeddings matrix of shape {self.embeddings.shape}.")
        else:
            checkpoint_file = self.embeddings_path.parent / "embeddings_checkpoint.npy"
            if checkpoint_file.exists():
                print(f"Retriever: Found partial checkpoint at {checkpoint_file}...")
            print("Retriever: Dense embeddings file not yet finalized. Operating in BM25 fallback mode.")
            self.embeddings = None

        self._is_indexed = True

    def filter_chunks(
        self,
        candidate_indices: List[int],
        min_year: Optional[int] = None,
        max_year: Optional[int] = None,
        keyword_filter: Optional[str] = None,
        author_filter: Optional[str] = None,
    ) -> List[int]:
        """Apply metadata filters to candidate chunk indices."""
        filtered = []
        for idx in candidate_indices:
            c = self.chunks[idx]
            pub_date = c.get("publication_date", "")
            year_match = re.match(r"^(\d{4})", pub_date)
            year = int(year_match.group(1)) if year_match else None

            if min_year and year and year < min_year:
                continue
            if max_year and year and year > max_year:
                continue
            if author_filter and author_filter.lower() not in c.get("authors", "").lower():
                continue
            if keyword_filter:
                kw_str = f"{c.get('mesh_terms', '')} {c.get('keywords', '')}".lower()
                if keyword_filter.lower() not in kw_str:
                    continue
            filtered.append(idx)
        return filtered

    def retrieve(
        self,
        query: str,
        top_k: int = DEFAULT_TOP_K,
        mode: str = "hybrid",  # "hybrid", "dense", "bm25"
        min_year: Optional[int] = None,
        max_year: Optional[int] = None,
        keyword_filter: Optional[str] = None,
        author_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Execute retrieval with specified mode, RRF, reranking, and metadata filtering.
        Fallback chain: Hybrid -> Dense-only -> BM25-only.
        """
        if not self._is_indexed:
            self.load_or_build_index()

        num_chunks = len(self.chunks)
        if num_chunks == 0:
            return []

        # 1. BM25 Retrieval
        bm25_scores = np.zeros(num_chunks, dtype=np.float32)
        bm25_ranks: Dict[int, int] = {}
        try:
            tokens = self.tokenize(query)
            if tokens and self.bm25:
                bm25_scores = np.array(self.bm25.get_scores(tokens), dtype=np.float32)
                top_bm25_indices = np.argsort(bm25_scores)[::-1][:60]
                for rank, idx in enumerate(top_bm25_indices):
                    if bm25_scores[idx] > 0:
                        bm25_ranks[int(idx)] = rank + 1
        except Exception as e:
            print(f"Retriever: BM25 scoring error: {e}")

        # 2. Dense Vector Retrieval
        dense_scores = np.zeros(num_chunks, dtype=np.float32)
        dense_ranks: Dict[int, int] = {}
        dense_available = False
        try:
            if self.embeddings is not None and len(self.embeddings) == num_chunks:
                q_emb = np.array(gateway_client.get_single_embedding(query), dtype=np.float32)
                q_norm = np.linalg.norm(q_emb)
                if q_norm > 0:
                    q_emb = q_emb / q_norm
                dense_scores = np.dot(self.embeddings, q_emb)
                top_dense_indices = np.argsort(dense_scores)[::-1][:60]
                for rank, idx in enumerate(top_dense_indices):
                    dense_ranks[int(idx)] = rank + 1
                dense_available = True
        except Exception as e:
            print(f"Retriever: Dense embedding error: {e}")

        # 3. Fusion & Fallback Logic
        candidate_pool = set(bm25_ranks.keys()).union(set(dense_ranks.keys()))

        # Determine effective mode based on availability and request
        if mode == "dense" and dense_available:
            effective_candidates = list(dense_ranks.keys())
        elif mode == "bm25" or not dense_available:
            effective_candidates = list(bm25_ranks.keys())
        else:
            # Hybrid
            if not dense_available and bm25_ranks:
                # Fallback to BM25
                print("Retriever: Falling back to BM25-only")
                effective_candidates = list(bm25_ranks.keys())
            elif not bm25_ranks and dense_available:
                # Fallback to Dense
                print("Retriever: Falling back to Dense-only")
                effective_candidates = list(dense_ranks.keys())
            else:
                effective_candidates = list(candidate_pool)

        # Apply metadata filters
        valid_candidates = self.filter_chunks(
            effective_candidates,
            min_year=min_year,
            max_year=max_year,
            keyword_filter=keyword_filter,
            author_filter=author_filter,
        )

        if not valid_candidates:
            return []

        # 4. Score calculation: RRF + Reranking features
        scored_candidates = []
        q_tokens_set = set(self.tokenize(query))

        for idx in valid_candidates:
            chunk = self.chunks[idx]
            b_rank = bm25_ranks.get(idx, 999)
            d_rank = dense_ranks.get(idx, 999)

            # Reciprocal Rank Fusion
            rrf_score = 0.0
            if b_rank <= 60:
                rrf_score += 1.0 / (RRF_K + b_rank)
            if d_rank <= 60:
                rrf_score += 1.0 / (RRF_K + d_rank)

            # Reranking features
            dense_sim = float(dense_scores[idx]) if dense_available else 0.0
            bm25_val = float(bm25_scores[idx])

            # Title term overlap boost
            title_tokens = set(self.tokenize(chunk.get("title", "")))
            title_overlap = len(q_tokens_set.intersection(title_tokens)) / max(len(q_tokens_set), 1)

            # MeSH / Keyword overlap boost
            kw_tokens = set(self.tokenize(f"{chunk.get('mesh_terms', '')} {chunk.get('keywords', '')}"))
            kw_overlap = len(q_tokens_set.intersection(kw_tokens)) / max(len(q_tokens_set), 1)

            # Combined reranking score
            final_score = (
                (rrf_score * 40.0)
                + (dense_sim * 0.40)
                + (title_overlap * 0.15)
                + (kw_overlap * 0.10)
            )

            scored_candidates.append({
                "chunk_index": idx,
                "chunk_id": chunk["chunk_id"],
                "pmid": chunk["pmid"],
                "title": chunk["title"],
                "abstract": chunk["abstract"],
                "publication_date": chunk["publication_date"],
                "authors": chunk["authors"],
                "mesh_terms": chunk["mesh_terms"],
                "keywords": chunk["keywords"],
                "text": chunk["text"],
                "score": round(float(final_score), 4),
                "rrf_score": round(float(rrf_score), 5),
                "dense_score": round(float(dense_sim), 4),
                "bm25_score": round(float(bm25_val), 2),
                "bm25_rank": b_rank if b_rank != 999 else None,
                "dense_rank": d_rank if d_rank != 999 else None,
            })

        # Sort by final score descending
        scored_candidates.sort(key=lambda x: x["score"], reverse=True)

        # Deduplicate by PMID to ensure diverse research papers in top-K
        deduped_results = []
        seen_pmids = set()
        for cand in scored_candidates:
            if cand["pmid"] not in seen_pmids:
                seen_pmids.add(cand["pmid"])
                deduped_results.append(cand)
            if len(deduped_results) >= top_k:
                break

        return deduped_results

retriever = HybridRetriever()
