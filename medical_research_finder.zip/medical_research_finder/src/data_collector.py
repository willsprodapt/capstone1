import csv
import json
import random
import re
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict, Any
import requests

from src.config import RAW_DATA_CSV, DATA_DIR

NCBI_ESEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
NCBI_EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

TOPIC_QUERIES = [
    ("mRNA vaccine respiratory infection", 350),
    ("diabetes cardiovascular complications", 350),
    ("cancer immunotherapy checkpoint inhibitor", 350),
    ("Alzheimer disease neurodegeneration treatment", 320),
    ("GLP-1 receptor agonist cardiovascular outcomes", 300),
    ("autoimmune rheumatoid arthritis biologic therapy", 300),
]

def fetch_pmids_for_query(query: str, count: int) -> List[str]:
    """Search NCBI for PMIDs matching query."""
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": count,
        "retmode": "json",
        "sort": "pub_date",
    }
    try:
        res = requests.get(NCBI_ESEARCH_URL, params=params, timeout=15)
        if res.status_code == 200:
            return res.json().get("esearchresult", {}).get("idlist", [])
    except Exception as e:
        print(f"Error fetching PMIDs for query '{query}': {e}")
    return []

def fetch_xml_batch(pmids: List[str]) -> List[Dict[str, str]]:
    """Fetch and parse XML records for a batch of PMIDs."""
    if not pmids:
        return []
    params = {
        "db": "pubmed",
        "id": ",".join(pmids),
        "retmode": "xml",
    }
    try:
        res = requests.get(NCBI_EFETCH_URL, params=params, timeout=30)
        if res.status_code != 200:
            print(f"EFetch status {res.status_code}")
            return []
        root = ET.fromstring(res.content)
        articles = root.findall(".//PubmedArticle")
        records = []
        for a in articles:
            pmid = a.findtext(".//PMID")
            if not pmid:
                continue
            title = a.findtext(".//ArticleTitle") or ""
            # Clean HTML tags in title
            title = re.sub(r"<[^>]+>", "", title).strip()

            # Abstract
            ab_elems = a.findall(".//Abstract/AbstractText")
            if ab_elems:
                ab_parts = []
                for elem in ab_elems:
                    lbl = elem.attrib.get("Label")
                    txt = elem.text or ""
                    if lbl:
                        ab_parts.append(f"{lbl}: {txt}")
                    else:
                        ab_parts.append(txt)
                abstract = " ".join(ab_parts).strip()
            else:
                abstract = a.findtext(".//Abstract") or ""
            abstract = re.sub(r"<[^>]+>", "", abstract).strip()

            # Authors
            authors = []
            for author in a.findall(".//AuthorList/Author"):
                last = author.findtext("LastName") or ""
                fore = author.findtext("ForeName") or ""
                if last or fore:
                    authors.append(f"{fore} {last}".strip())
            authors_str = "; ".join(authors) if authors else "Unknown Authors"

            # Date
            year = a.findtext(".//Journal/JournalIssue/PubDate/Year") or a.findtext(".//DateCompleted/Year") or a.findtext(".//DateRevised/Year") or "2023"
            month = a.findtext(".//Journal/JournalIssue/PubDate/Month") or "01"
            # Normalize month string if 3-letter abbreviation
            month_map = {"Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12"}
            month = month_map.get(month[:3].capitalize(), month if month.isdigit() and len(month) <= 2 else "01").zfill(2)
            day = a.findtext(".//Journal/JournalIssue/PubDate/Day") or "01"
            day = day.zfill(2) if day.isdigit() else "01"
            pub_date = f"{year}-{month}-{day}"

            # MeSH Terms
            mesh_terms = [m.text for m in a.findall(".//MeshHeading/DescriptorName") if m.text]
            mesh_str = "; ".join(mesh_terms)

            # Keywords
            keywords = [k.text for k in a.findall(".//KeywordList/Keyword") if k.text]
            keywords_str = "; ".join(keywords)

            records.append({
                "PMID": pmid,
                "Title": title,
                "Abstract": abstract,
                "Authors": authors_str,
                "Publication Date": pub_date,
                "MeSH Terms": mesh_str,
                "Keywords": keywords_str,
            })
        return records
    except Exception as e:
        print(f"Error parsing XML batch: {e}")
        return []

def generate_curated_anomaly_records(base_records: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    Generate realistic anomalies for the validation pipeline to evaluate:
    - Duplicate PMIDs
    - Missing abstracts
    - Invalid dates
    - Year/Metadata inconsistencies
    - Obvious non-medical abstracts
    - Malformed records
    """
    anomalies = []
    
    # 1. Duplicate PMIDs (reuse existing PMIDs from base)
    if len(base_records) >= 6:
        for i in range(6):
            orig = base_records[i]
            dup = dict(orig)
            dup["Title"] = f"[Duplicate] {orig['Title']}"
            anomalies.append(dup)

    # 2. Missing Abstracts (8 records)
    for i in range(8):
        anomalies.append({
            "PMID": f"9000100{i}",
            "Title": f"Clinical observations on cardiac rehabilitation protocol {i+1}",
            "Abstract": "",  # Empty abstract
            "Authors": f"Smith J; Taylor R{i}",
            "Publication Date": "2023-04-15",
            "MeSH Terms": "Cardiology; Rehabilitation",
            "Keywords": "cardiac rehab; exercise therapy",
        })

    # 3. Invalid dates (6 records)
    invalid_dates = ["9999-99-99", "INVALID_DATE", "1840-02-30", "2024/15/45", "N/A", "0000-00-00"]
    for i, bad_date in enumerate(invalid_dates):
        anomalies.append({
            "PMID": f"9000200{i}",
            "Title": f"Retrospective cohort analysis of metformin adherence in elderly diabetic patients group {i+1}",
            "Abstract": "This retrospective study examines glycemic control and medication adherence across 450 type-2 diabetes patients treated with metformin monotherapy or combination therapy over a five-year follow-up period.",
            "Authors": f"Davis M; Rodriguez K{i}",
            "Publication Date": bad_date,
            "MeSH Terms": "Diabetes Mellitus, Type 2; Metformin; Medication Adherence",
            "Keywords": "metformin; type 2 diabetes; adherence",
        })

    # 4. Metadata inconsistencies (8 records - e.g. Year says 2005 but abstract specifically references post-2023 trials)
    for i in range(8):
        anomalies.append({
            "PMID": f"9000300{i}",
            "Title": f"Long-term efficacy of bivalent mRNA boosters evaluated in multi-center randomized cohort {i+1}",
            "Abstract": "Conducted in late 2023 and early 2024 across 12 tertiary medical centers, this clinical evaluation assessed neutralization titers against emerging SARS-CoV-2 omicron subvariants JN.1 and BA.2.86 following bivalent vaccination.",
            "Authors": f"Chen L; Zhao W{i}",
            "Publication Date": "2008-05-12",  # Blatant date inconsistency with 2023/2024 trial
            "MeSH Terms": "COVID-19 Vaccines; Immunity; Neutralization",
            "Keywords": "bivalent booster; neutralization; JN.1",
        })

    # 5. Non-medical records (6 records - computer graphics, culinary, astronomy)
    non_med = [
        ("90004001", "Real-Time Ray Tracing and Rasterization in Modern GPUs", "We present a novel hardware acceleration structure for bounding volume hierarchy traversal in real-time path tracing algorithms on modern desktop GPUs.", "Nvidia G; Radeon A", "2023-09-10", "Computer Graphics; GPU", "ray tracing; rendering"),
        ("90004002", "Thermodynamics of Sourdough Bread Fermentation and Crumb Porosity", "This food science paper evaluates lactic acid bacteria kinetics and yeast carbon dioxide production during high-hydration sourdough bread proofing.", "Baker P; Flour M", "2022-11-05", "Baking; Food Science", "sourdough; fermentation; baking"),
        ("90004003", "Orbital Resonance and Tidal Heating in Galilean Satellites", "We simulate tidal dissipation in Europa and Io to constrain internal subsurface ocean thickness and orbital eccentricity stabilization.", "Kepler J; Galilei G", "2021-08-20", "Astronomy; Celestial Mechanics", "Europa; tidal heating; resonance"),
        ("90004004", "Deep Reinforcement Learning for Chess Endgame Tablebases", "Evaluating Monte Carlo tree search combined with deep residual networks for solving seven-piece endgame positions in tournament chess.", "Kasparov G; Carlsen M", "2024-02-14", "Artificial Intelligence; Game Theory", "chess; reinforcement learning"),
        ("90004005", "Aerodynamic Lift Optimization for Transonic Commercial Aircraft Wings", "Computational fluid dynamics simulations of supercritical airfoil camber designs to reduce shock wave drag at Mach 0.82.", "Boeing W; Airbus E", "2023-06-30", "Aerodynamics; Aeronautics", "transonic flight; airfoil; CFD"),
        ("90004006", "Synthesis and Acoustic Properties of Brazilian Rosewood Guitars", "Vibrational modal analysis of soundboards constructed from Dalbergia nigra versus synthetic carbon fiber laminates.", "Stradivari A; Martin C", "2022-04-18", "Acoustics; Musical Instruments", "guitar acoustics; resonance; wood"),
    ]
    for pmid, title, ab, authors, dt, mesh, kw in non_med:
        anomalies.append({
            "PMID": pmid,
            "Title": title,
            "Abstract": ab,
            "Authors": authors,
            "Publication Date": dt,
            "MeSH Terms": mesh,
            "Keywords": kw,
        })

    # 6. Malformed title/author structure (6 records)
    for i in range(6):
        anomalies.append({
            "PMID": f"9000500{i}",
            "Title": f"Short {i}",  # Incomplete title (< 10 chars)
            "Abstract": "A clinical study describing pharmacological treatment in pediatric pulmonary disease.",
            "Authors": "",  # Empty authors
            "Publication Date": "2023-01-10",
            "MeSH Terms": "Pediatrics",
            "Keywords": "pediatric; pulmonology",
        })

    return anomalies

def collect_2000_pubmed_records(target_total: int = 2000) -> List[Dict[str, str]]:
    """
    Collect ~1,960 authentic PubMed records via NCBI E-utilities,
    combine with curated anomaly records to reach exactly 2,000 records.
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    all_pmids: List[str] = []
    seen_pmids = set()

    print("Step 1: Searching PubMed across medical topics...")
    for query, count in TOPIC_QUERIES:
        print(f"  Searching: '{query}' (target: {count})...")
        ids = fetch_pmids_for_query(query, count)
        for p in ids:
            if p not in seen_pmids:
                seen_pmids.add(p)
                all_pmids.append(p)
        time.sleep(0.5)

    print(f"Found {len(all_pmids)} unique PMIDs from NCBI search.")
    
    # We want ~1960 clean authentic records so + 40 anomalies = 2000 records
    needed_clean = target_total - 40
    fetch_pmids = all_pmids[:needed_clean + 100]  # buffer

    print(f"Step 2: Fetching full XML metadata in batches for {len(fetch_pmids)} articles...")
    all_records: List[Dict[str, str]] = []
    batch_size = 150
    for i in range(0, len(fetch_pmids), batch_size):
        batch = fetch_pmids[i : i + batch_size]
        print(f"  Fetching batch {i//batch_size + 1}/{(len(fetch_pmids)-1)//batch_size + 1} ({len(batch)} records)...")
        batch_records = fetch_xml_batch(batch)
        for r in batch_records:
            if r["Abstract"] and len(r["Abstract"]) > 80:  # ensure base records are quality
                all_records.append(r)
            if len(all_records) >= needed_clean:
                break
        if len(all_records) >= needed_clean:
            break
        time.sleep(0.5)

    print(f"Collected {len(all_records)} authentic PubMed records.")

    print("Step 3: Integrating realistic curated anomaly records (duplicates, missing abstracts, invalid dates, etc.)...")
    anomalies = generate_curated_anomaly_records(all_records)
    print(f"Generated {len(anomalies)} test anomalies.")

    # Trim authentic to exactly (target_total - len(anomalies))
    clean_count = target_total - len(anomalies)
    final_records = all_records[:clean_count] + anomalies
    random.seed(42)
    random.shuffle(final_records)

    print(f"Final dataset count: {len(final_records)} records.")

    # Write to CSV
    fieldnames = ["PMID", "Title", "Abstract", "Authors", "Publication Date", "MeSH Terms", "Keywords"]
    with open(RAW_DATA_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_records)

    print(f"Saved {len(final_records)} records to {RAW_DATA_CSV}")
    return final_records

if __name__ == "__main__":
    collect_2000_pubmed_records(2000)
