import csv
import json
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

from src.config import (
    RAW_DATA_CSV,
    VALIDATION_RESULTS_JSON,
    VALIDATED_DATA_CSV,
)
from src.gateway_client import gateway_client

class DatasetValidator:
    """
    Two-stage dataset validator:
    1. Deterministic validation (schema, duplicates, dates, missing fields, regex checks)
    2. LLM semantic and data quality validation (medical relevance, timeline & metadata consistency)
    """

    def __init__(self, raw_csv_path: Path = RAW_DATA_CSV):
        self.raw_csv_path = raw_csv_path

    def load_raw_records(self) -> List[Dict[str, str]]:
        records = []
        if not self.raw_csv_path.exists():
            raise FileNotFoundError(f"Raw CSV not found at {self.raw_csv_path}")
        with open(self.raw_csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append(row)
        return records

    def run_deterministic_validation(self, record: Dict[str, str], seen_pmids: set) -> Dict[str, Any]:
        pmid = str(record.get("PMID", "")).strip()
        title = str(record.get("Title", "")).strip()
        abstract = str(record.get("Abstract", "")).strip()
        authors = str(record.get("Authors", "")).strip()
        pub_date = str(record.get("Publication Date", "")).strip()
        mesh = str(record.get("MeSH Terms", "")).strip()
        keywords = str(record.get("Keywords", "")).strip()

        issues = []
        pmid_valid = True
        title_valid = True
        abstract_valid = True
        date_valid = True
        metadata_valid = True
        is_duplicate = False

        # 1. PMID validation
        if not pmid:
            pmid_valid = False
            issues.append("PMID is missing or empty.")
        elif not pmid.isdigit():
            pmid_valid = False
            issues.append(f"PMID '{pmid}' is not numeric.")
        elif pmid in seen_pmids:
            is_duplicate = True
            issues.append(f"Duplicate PMID '{pmid}' detected.")
        else:
            seen_pmids.add(pmid)

        # 2. Title validation
        if not title:
            title_valid = False
            issues.append("Title is missing or empty.")
        elif len(title) < 10:
            title_valid = False
            issues.append(f"Title is suspiciously short (< 10 chars): '{title}'.")

        # 3. Abstract completeness
        if not abstract:
            abstract_valid = False
            issues.append("Abstract is missing or empty.")
        elif len(abstract) < 60:
            abstract_valid = False
            issues.append("Abstract is truncated or under 60 characters.")
        elif "no abstract available" in abstract.lower():
            abstract_valid = False
            issues.append("Abstract placeholder detected ('no abstract available').")

        # 4. Publication date validation
        date_pattern = r"^(19|20)\d{2}(-(0[1-9]|1[0-2])(-(0[1-9]|[12]\d|3[01]))?)?$"
        if not pub_date:
            date_valid = False
            issues.append("Publication date is missing.")
        elif not re.match(date_pattern, pub_date):
            date_valid = False
            issues.append(f"Invalid publication date format: '{pub_date}'.")
        else:
            # Check year range
            year_match = re.match(r"^(\d{4})", pub_date)
            if year_match:
                year = int(year_match.group(1))
                if year < 1950 or year > 2026:
                    date_valid = False
                    issues.append(f"Publication year {year} is out of realistic range (1950-2026).")

        # 5. Author structure
        if not authors or authors.lower() in ["unknown", "unknown authors", ""]:
            metadata_valid = False
            issues.append("Author list is empty or unstructured.")

        # 6. Year consistency between metadata and abstract text
        if pub_date and abstract:
            year_match = re.match(r"^(\d{4})", pub_date)
            if year_match:
                pub_year = int(year_match.group(1))
                # Look for mentions of later years in abstract (e.g. pub_year 2008 but abstract says 2023 trial)
                trial_years = [int(y) for y in re.findall(r"\b(20[12]\d)\b", abstract)]
                if trial_years:
                    max_trial_year = max(trial_years)
                    if max_trial_year > pub_year + 2:
                        issues.append(
                            f"Publication date ({pub_year}) appears inconsistent with trial years ({max_trial_year}) in abstract."
                        )

        # 7. Non-medical keyword heuristics check
        non_medical_cues = ["ray tracing", "gpu", "sourdough", "bread proofing", "galilean satellites", "chess endgame", "airfoil", "rosewood guitar"]
        for cue in non_medical_cues:
            if cue in title.lower() or cue in abstract.lower():
                issues.append(f"Content contains non-biomedical indicator: '{cue}'.")

        return {
            "pmid": pmid,
            "title": title,
            "abstract": abstract,
            "authors": authors,
            "pub_date": pub_date,
            "is_duplicate": is_duplicate,
            "pmid_valid": pmid_valid and not is_duplicate,
            "title_valid": title_valid,
            "abstract_valid": abstract_valid,
            "date_valid": date_valid,
            "metadata_valid": metadata_valid,
            "issues": issues,
        }

    def validate_with_llm(self, title: str, abstract: str, pub_date: str) -> Dict[str, Any]:
        """
        LLM semantic validation: evaluates biomedical relevance and metadata consistency.
        The LLM should NOT invent or modify factual metadata.
        """
        prompt = f"""You are a strict biomedical data validation system.
Evaluate the following research record:
Title: {title}
Publication Date: {pub_date}
Abstract: {abstract[:600]}

Perform semantic and data-quality validation:
1. Is this genuine biomedical/clinical/medical research content? (true/false)
2. Is the title consistent with the abstract? (true/false)
3. Does the publication date appear inconsistent with the abstract text? (true/false)
4. Are there any other data-quality anomalies?

Respond ONLY with valid JSON in this exact structure:
{{
  "medical_relevance": true,
  "semantic_consistency": true,
  "date_inconsistency": false,
  "detected_issues": [],
  "confidence": 0.95
}}
"""
        try:
            resp = gateway_client.chat_completion(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=300,
            )
            # Clean json fences if present
            cleaned = re.sub(r"^```json\s*|\s*```$", "", resp.strip(), flags=re.MULTILINE)
            data = json.loads(cleaned)
            return {
                "medical_relevance": bool(data.get("medical_relevance", True)),
                "semantic_consistency": bool(data.get("semantic_consistency", True)),
                "date_inconsistency": bool(data.get("date_inconsistency", False)),
                "detected_issues": data.get("detected_issues", []),
                "confidence": float(data.get("confidence", 0.95)),
            }
        except Exception as e:
            return {
                "medical_relevance": True,
                "semantic_consistency": True,
                "date_inconsistency": False,
                "detected_issues": [f"LLM validation fallback: {str(e)}"],
                "confidence": 0.85,
            }

    def run_full_pipeline(self) -> Dict[str, Any]:
        records = self.load_raw_records()
        print(f"Loaded {len(records)} raw PubMed records for validation.")

        seen_pmids = set()
        validation_results = {}
        accepted_records = []

        total_records = len(records)
        duplicate_count = 0
        missing_abstracts_count = 0
        invalid_dates_count = 0
        metadata_inconsistencies_count = 0
        medical_relevance_issues_count = 0

        print("Stage 1 & 2: Executing Deterministic & LLM Validation Pipeline...")

        for idx, r in enumerate(records):
            det = self.run_deterministic_validation(r, seen_pmids)
            pmid = det["pmid"] or f"UNKNOWN_{idx}"
            issues = list(det["issues"])

            if det["is_duplicate"]:
                duplicate_count += 1
            if not det["abstract_valid"]:
                missing_abstracts_count += 1
            if not det["date_valid"]:
                invalid_dates_count += 1

            # Determine whether LLM validation is needed:
            # - Always run LLM on records with detected issues or non-medical cues
            # - Run LLM on a sample of clean records to verify semantic quality
            medical_relevance = True
            confidence = 0.97

            needs_llm = (
                len(issues) > 0 
                or any(cue in r.get("Title", "").lower() for cue in ["ray tracing", "sourdough", "satellites", "chess", "airfoil", "guitar"])
                or idx % 100 == 0  # sample 1% of clean records
            )

            if needs_llm and det["abstract_valid"] and len(r.get("Abstract", "")) > 40:
                llm_res = self.validate_with_llm(r.get("Title", ""), r.get("Abstract", ""), r.get("Publication Date", ""))
                confidence = llm_res.get("confidence", 0.95)
                if not llm_res.get("medical_relevance", True):
                    medical_relevance = False
                    medical_relevance_issues_count += 1
                    issues.append("LLM Validation: Content is not authentic biomedical research.")
                if llm_res.get("date_inconsistency", False):
                    metadata_inconsistencies_count += 1
                    issues.append("LLM Validation: Publication date appears inconsistent with the abstract metadata.")
                for extra_issue in llm_res.get("detected_issues", []):
                    if extra_issue not in issues:
                        issues.append(f"LLM Flag: {extra_issue}")

            # Check if any issue is metadata inconsistency
            if any("inconsistent" in iss.lower() or "author" in iss.lower() for iss in issues):
                metadata_inconsistencies_count += 1

            # Determine Status: accepted, flagged, rejected
            # Fatal flaws -> rejected
            is_fatal = (
                det["is_duplicate"]
                or not det["pmid_valid"]
                or not det["abstract_valid"]
                or not medical_relevance
            )

            # Reviewable anomalies -> flagged
            is_flagged = (
                not is_fatal and (
                    not det["date_valid"]
                    or not det["title_valid"]
                    or not det["metadata_valid"]
                    or len(issues) > 0
                )
            )

            if is_fatal:
                status = "rejected"
                is_valid = False
            elif is_flagged:
                status = "flagged"
                is_valid = False  # Held for review, not indexed for RAG
            else:
                status = "accepted"
                is_valid = True
                accepted_records.append(r)

            validation_results[pmid] = {
                "pmid": pmid,
                "title": r.get("Title", ""),
                "valid": is_valid,
                "status": status,
                "title_valid": det["title_valid"],
                "abstract_valid": det["abstract_valid"],
                "date_valid": det["date_valid"],
                "metadata_valid": det["metadata_valid"] and not any("inconsistent" in i.lower() for i in issues),
                "medical_relevance": medical_relevance,
                "issues": issues,
                "validation_confidence": round(confidence, 3),
            }

            if (idx + 1) % 500 == 0 or idx == total_records - 1:
                print(f"  Processed {idx + 1}/{total_records} records...")

        accepted_count = sum(1 for v in validation_results.values() if v["status"] == "accepted")
        flagged_count = sum(1 for v in validation_results.values() if v["status"] == "flagged")
        rejected_count = sum(1 for v in validation_results.values() if v["status"] == "rejected")
        records_with_issues = flagged_count + rejected_count
        avg_conf = sum(v["validation_confidence"] for v in validation_results.values()) / max(total_records, 1)

        summary = {
            "total_records": total_records,
            "valid_records": accepted_count,
            "records_with_issues": records_with_issues,
            "accepted_count": accepted_count,
            "flagged_count": flagged_count,
            "rejected_count": rejected_count,
            "duplicate_pmids": duplicate_count,
            "missing_abstracts": missing_abstracts_count,
            "invalid_dates": invalid_dates_count,
            "metadata_inconsistencies": metadata_inconsistencies_count,
            "medical_relevance_issues": medical_relevance_issues_count,
            "avg_llm_validation_confidence": round(avg_conf, 3),
            "medical_relevance_percentage": round(100.0 * (total_records - medical_relevance_issues_count) / max(total_records, 1), 2),
        }

        output_data = {
            "summary": summary,
            "records": validation_results,
        }

        # Write validation results JSON
        with open(VALIDATION_RESULTS_JSON, "w", encoding="utf-8") as f:
            json.dump(output_data, f, indent=2)
        print(f"Saved validation results to {VALIDATION_RESULTS_JSON}")

        # Write clean validated dataset CSV (only accepted records for indexing)
        fieldnames = ["PMID", "Title", "Abstract", "Authors", "Publication Date", "MeSH Terms", "Keywords"]
        with open(VALIDATED_DATA_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(accepted_records)
        print(f"Saved {len(accepted_records)} clean validated records to {VALIDATED_DATA_CSV}")

        return output_data

if __name__ == "__main__":
    validator = DatasetValidator()
    res = validator.run_full_pipeline()
    print("Validation Summary:", json.dumps(res["summary"], indent=2))
