import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Data Paths
DATA_DIR = BASE_DIR / "data"
RAW_DATA_CSV = DATA_DIR / "pubmed_2000.csv"
VALIDATION_RESULTS_JSON = DATA_DIR / "validation_results.json"
VALIDATED_DATA_CSV = DATA_DIR / "validated_pubmed.csv"
CHUNKS_JSON = DATA_DIR / "chunks.json"
EMBEDDINGS_NPY = DATA_DIR / "embeddings.npy"
EVALUATION_RESULTS_JSON = DATA_DIR / "evaluation_results.json"

# OpenAI Gateway API
GATEWAY_URL = os.environ.get("GATEWAY_URL", "https://keygateway1.arshnivlabs.com")
LEARNER_KEY = os.environ.get("LEARNER_KEY", "pubatch11")

# Gateway Headers
GATEWAY_HEADERS = {
    "Authorization": f"Bearer {LEARNER_KEY}",
    "Content-Type": "application/json",
}

# RAG & Retrieval Parameters
RRF_K = 60
DEFAULT_TOP_K = 5
MAX_RETRIEVAL_CANDIDATES = 20
GROUNDING_SIMILARITY_THRESHOLD = 0.52

# Server Settings
HOST = "0.0.0.0"
PORT = 5000
