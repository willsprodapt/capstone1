import re
from typing import List, Dict, Any, Optional

from src.gateway_client import gateway_client

class RAGEngine:
    """
    Genuine Retrieval-Augmented Generation (RAG) engine.
    Synthesizes research summaries and answers strictly and exclusively from retrieved evidence documents.
    """

    def build_context(self, retrieved_docs: List[Dict[str, Any]]) -> str:
        """
        Construct structured RAG context from retrieved research papers.
        Each document block preserves full provenance: PMID, title, date, authors, abstract, MeSH, keywords.
        """
        context_blocks = []
        for idx, doc in enumerate(retrieved_docs, start=1):
            block = (
                f"[DOCUMENT {idx}]\n"
                f"PMID: {doc.get('pmid', 'N/A')}\n"
                f"Title: {doc.get('title', 'N/A')}\n"
                f"Publication Date: {doc.get('publication_date', 'N/A')}\n"
                f"Authors: {doc.get('authors', 'N/A')}\n"
                f"Abstract: {doc.get('abstract', 'N/A')}\n"
                f"MeSH: {doc.get('mesh_terms', 'None')}\n"
                f"Keywords: {doc.get('keywords', 'None')}\n"
            )
            context_blocks.append(block)
        return "\n".join(context_blocks)

    def generate_response(
        self,
        query: str,
        retrieved_docs: List[Dict[str, Any]],
        temperature: float = 0.2,
    ) -> str:
        """
        Generate grounded research synthesis based solely on retrieved research evidence.
        """
        if not retrieved_docs:
            return (
                "## Research Summary\n"
                "The retrieved evidence is insufficient to answer the research question. "
                "No relevant research papers matching the query criteria were found in the knowledge base.\n\n"
                "## Limitations of the Retrieved Evidence\n"
                "Knowledge base yielded zero matching documents under current search filters."
            )

        context_str = self.build_context(retrieved_docs)

        system_prompt = (
            "You are an AI-powered medical research assistant designed to synthesize research evidence.\n"
            "CRITICAL INSTRUCTIONS:\n"
            "1. You are answering using ONLY the retrieved research evidence provided below.\n"
            "2. Do NOT rely on outside knowledge or pretrained assumptions.\n"
            "3. If the retrieved evidence does not answer the question or is inadequate, state that the evidence is insufficient.\n"
            "4. MANDATORY CITATION RULE: Every single bullet point and factual statement in Key Findings, Evidence by Study, and Comparison Across Studies MUST end with an explicit citation: [PMID: <pmid>].\n"
            "   Example: '- mRNA-1345 showed 85% effectiveness against hospitalizations [PMID: 38291024].'\n"
            "5. Never invent or hallucinate a PMID not present in the provided documents.\n"
            "6. Do NOT provide direct clinical or medical advice; maintain formal, objective scientific research language.\n"
            "7. If evidence conflicts across studies, explicitly detail and contrast the conflicting findings.\n"
            "8. Follow this exact response structure with concise, high-density scientific bullet points:\n\n"
            "## Research Summary\n"
            "## Key Findings\n"
            "## Evidence by Study\n"
            "## Comparison Across Studies\n"
            "## Limitations of the Retrieved Evidence\n"
            "## Sources\n"
        )

        user_prompt = (
            f"RESEARCH QUESTION:\n{query}\n\n"
            f"RETRIEVED RESEARCH EVIDENCE ({len(retrieved_docs)} papers):\n"
            f"=====================================================\n"
            f"{context_str}\n"
            f"=====================================================\n\n"
            "Please generate the grounded research synthesis adhering strictly to the required structure and citation rules. Keep sections concise and focused."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        response_text = gateway_client.chat_completion(messages, temperature=temperature, max_tokens=500)
        return response_text

    def generate_chat_response(
        self,
        message: str,
        retrieved_docs: List[Dict[str, Any]],
        history: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.2,
    ) -> str:
        """
        Conversational RAG synthesis: directly answers the user's specific prompt about the research papers,
        while strictly enforcing zero-pretrained hallucination and mandatory [PMID: <pmid>] citations.
        """
        if not retrieved_docs:
            return (
                "The retrieved research evidence is insufficient to answer your question. "
                "None of the validated research papers in the knowledge base match the query criteria or contain information on this topic."
            )

        context_str = self.build_context(retrieved_docs)

        system_prompt = (
            "You are an interactive AI Medical Research Assistant answering questions about peer-reviewed PubMed research papers.\n"
            "CRITICAL INSTRUCTIONS:\n"
            "1. Answer the user's question directly and informatively using ONLY the retrieved research papers below.\n"
            "2. Do NOT rely on outside knowledge or pretrained assumptions. If the papers do not contain the answer, explicitly state that the evidence is insufficient.\n"
            "3. MANDATORY CITATION RULE: Every factual claim, finding, statistic, or observation MUST be cited with the exact format [PMID: <pmid>].\n"
            "   Example: 'The trial observed an 85% reduction in RSV-associated hospitalizations [PMID: 42424857].'\n"
            "4. Never invent or hallucinate a PMID not present in the provided evidence.\n"
            "5. Do NOT give medical advice; maintain objective, scientific research tone.\n"
            "6. If the user asks about a specific paper or comparison, focus directly on the relevant paper(s) from the retrieved set.\n"
            "7. Keep your answer structured, clear, and concise with bullet points where appropriate."
        )

        messages = [{"role": "system", "content": system_prompt}]

        # Include recent history (up to last 4 messages) for conversation flow
        if history:
            for h in history[-4:]:
                role = h.get("role", "user")
                content = h.get("content", "")
                if role in ["user", "assistant"] and content:
                    # Strip out massive previous context dumps to save token budget
                    messages.append({"role": role, "content": content[:600]})

        current_prompt = (
            f"RETRIEVED RESEARCH EVIDENCE ({len(retrieved_docs)} papers from knowledge base):\n"
            f"=====================================================\n"
            f"{context_str}\n"
            f"=====================================================\n\n"
            f"USER QUESTION:\n{message}\n\n"
            "Answer the question accurately using ONLY the evidence above. Every factual statement must cite [PMID: <pmid>]."
        )
        messages.append({"role": "user", "content": current_prompt})

        response_text = gateway_client.chat_completion(messages, temperature=temperature, max_tokens=500)
        return response_text

rag_engine = RAGEngine()
