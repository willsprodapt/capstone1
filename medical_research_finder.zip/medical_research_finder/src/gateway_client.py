import time
import requests
from typing import List, Dict, Any, Optional
from src.config import GATEWAY_URL, GATEWAY_HEADERS

class GatewayClient:
    """
    Client for interacting with OpenAI Gateway at https://keygateway1.arshnivlabs.com.
    Note: Do NOT set `model` parameter in requests. The gateway routes chat to
    `gpt-4o-mini` and embeddings to `text-embedding-3-small` automatically.
    """
    def __init__(self, gateway_url: str = GATEWAY_URL, headers: Optional[Dict[str, str]] = None):
        self.gateway_url = gateway_url.rstrip("/")
        self.headers = headers or GATEWAY_HEADERS

    def health_check(self) -> bool:
        try:
            res = requests.get(f"{self.gateway_url}/v1/health", headers=self.headers, timeout=10)
            return res.status_code == 200
        except Exception:
            return False

    def get_embeddings(self, texts: List[str], batch_size: int = 32, max_retries: int = 6) -> List[List[float]]:
        """
        Fetch vector embeddings for a list of texts in batches with exponential backoff.
        """
        all_embeddings: List[List[float]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            # Clean and sanitize strings: limit length to 4000 chars to prevent token overflow
            batch = [t[:4000].strip() if t.strip() else "medical study" for t in batch]
            payload = {"input": batch}

            success = False
            last_err = ""
            for attempt in range(max_retries):
                try:
                    res = requests.post(
                        f"{self.gateway_url}/v1/embeddings",
                        headers=self.headers,
                        json=payload,
                        timeout=60,
                    )
                    if res.status_code == 200:
                        data = res.json()
                        items = sorted(data.get("data", []), key=lambda x: x.get("index", 0))
                        for item in items:
                            all_embeddings.append(item["embedding"])
                        success = True
                        break
                    else:
                        last_err = f"HTTP {res.status_code}: {res.text[:150]}"
                        time.sleep(2.0 * (attempt + 1))
                except Exception as e:
                    last_err = str(e)
                    time.sleep(2.0 * (attempt + 1))

            if not success:
                raise RuntimeError(f"Failed to generate embeddings for batch starting at index {i}: {last_err}")

        return all_embeddings

    def get_single_embedding(self, text: str) -> List[float]:
        clean_text = text[:4000].strip() if text.strip() else "medical research"
        res = self.get_embeddings([clean_text], batch_size=1)
        return res[0]

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int = 500,
        max_retries: int = 5,
    ) -> str:
        """
        Send a chat completion request without model param.
        Enforces gateway maximum limit of 500 tokens.
        """
        clamped_tokens = min(int(max_tokens), 500)
        payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": clamped_tokens,
        }

        last_err = ""
        for attempt in range(max_retries):
            try:
                res = requests.post(
                    f"{self.gateway_url}/v1/chat/completions",
                    headers=self.headers,
                    json=payload,
                    timeout=60,
                )
                if res.status_code == 200:
                    data = res.json()
                    choices = data.get("choices", [])
                    if choices:
                        return choices[0]["message"]["content"]
                last_err = f"HTTP {res.status_code}: {res.text[:150]}"
                time.sleep(2.0 * (attempt + 1))
            except Exception as e:
                last_err = str(e)
                time.sleep(2.0 * (attempt + 1))

        raise RuntimeError(f"Failed to obtain chat completion from Gateway: {last_err}")

gateway_client = GatewayClient()
