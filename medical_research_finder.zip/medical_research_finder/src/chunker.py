import csv
import json
import re
from pathlib import Path
from typing import List, Dict, Any

from src.config import VALIDATED_DATA_CSV, CHUNKS_JSON

class DocumentChunker:
    """
    Splits validated research records into structured, searchable chunks
    while strictly preserving data provenance (PMID, title, date, chunk_id, source_document_id).
    """

    def __init__(self, validated_csv_path: Path = VALIDATED_DATA_CSV):
        self.validated_csv_path = validated_csv_path

    def load_validated_records(self) -> List[Dict[str, str]]:
        if not self.validated_csv_path.exists():
            raise FileNotFoundError(f"Validated CSV not found at {self.validated_csv_path}")
        records = []
        with open(self.validated_csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append(row)
        return records

    def clean_searchable_text(self, text: str) -> str:
        """Create normalized searchable text."""
        # Replace multiple spaces/newlines
        t = re.sub(r"\s+", " ", text)
        return t.strip()

    def chunk_document(self, record: Dict[str, str]) -> List[Dict[str, Any]]:
        pmid = str(record["PMID"]).strip()
        title = str(record["Title"]).strip()
        abstract = str(record["Abstract"]).strip()
        pub_date = str(record["Publication Date"]).strip()
        authors = str(record.get("Authors", "")).strip()
        mesh = str(record.get("MeSH Terms", "")).strip()
        keywords = str(record.get("Keywords", "")).strip()

        chunks = []

        # If abstract is relatively short/standard (<= 1400 chars)
        if len(abstract) <= 1400:
            full_text = f"Title: {title}\nAbstract: {abstract}"
            if mesh:
                full_text += f"\nMeSH: {mesh}"
            if keywords:
                full_text += f"\nKeywords: {keywords}"

            chunk = {
                "chunk_id": f"{pmid}_01",
                "pmid": pmid,
                "title": title,
                "publication_date": pub_date,
                "authors": authors,
                "mesh_terms": mesh,
                "keywords": keywords,
                "text": self.clean_searchable_text(full_text),
                "abstract": abstract,
                "source_document_id": pmid,
                "chunk_index": 0,
                "total_chunks": 1,
            }
            chunks.append(chunk)
        else:
            # Long abstract: split into 2 coherent sections (e.g. background/methods and results/conclusions)
            sentences = re.split(r"(?<=[.!?])\s+", abstract)
            mid = max(1, len(sentences) // 2)
            part1 = " ".join(sentences[:mid])
            part2 = " ".join(sentences[mid:])

            chunk1_text = f"Title: {title} [Part 1 - Context & Methodology]\nAbstract: {part1}"
            chunk2_text = f"Title: {title} [Part 2 - Findings & Implications]\nAbstract: {part2}"

            if mesh:
                chunk1_text += f"\nMeSH: {mesh}"
                chunk2_text += f"\nMeSH: {mesh}"

            chunks.append({
                "chunk_id": f"{pmid}_01",
                "pmid": pmid,
                "title": title,
                "publication_date": pub_date,
                "authors": authors,
                "mesh_terms": mesh,
                "keywords": keywords,
                "text": self.clean_searchable_text(chunk1_text),
                "abstract": abstract,
                "source_document_id": pmid,
                "chunk_index": 0,
                "total_chunks": 2,
            })

            chunks.append({
                "chunk_id": f"{pmid}_02",
                "pmid": pmid,
                "title": title,
                "publication_date": pub_date,
                "authors": authors,
                "mesh_terms": mesh,
                "keywords": keywords,
                "text": self.clean_searchable_text(chunk2_text),
                "abstract": abstract,
                "source_document_id": pmid,
                "chunk_index": 1,
                "total_chunks": 2,
            })

        return chunks

    def process_and_save(self) -> List[Dict[str, Any]]:
        records = self.load_validated_records()
        all_chunks = []
        for r in records:
            chunks = self.chunk_document(r)
            all_chunks.extend(chunks)

        with open(CHUNKS_JSON, "w", encoding="utf-8") as f:
            json.dump(all_chunks, f, indent=2)

        print(f"Generated {len(all_chunks)} chunks from {len(records)} validated documents.")
        print(f"Saved chunks to {CHUNKS_JSON}")
        return all_chunks

if __name__ == "__main__":
    chunker = DocumentChunker()
    chunker.process_and_save()
