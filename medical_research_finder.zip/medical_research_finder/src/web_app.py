import csv
import json
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory

from src.config import (
    RAW_DATA_CSV,
    VALIDATED_DATA_CSV,
    VALIDATION_RESULTS_JSON,
    EVALUATION_RESULTS_JSON,
    HOST,
    PORT,
)
from src.retriever import retriever
from src.rag_engine import rag_engine
from src.grounding_verifier import grounding_verifier

app = Flask(
    __name__,
    template_folder=str(Path(__file__).resolve().parent.parent / "templates"),
    static_folder=str(Path(__file__).resolve().parent.parent / "static"),
)

# Cache loaded records for fast paper modal lookup
_PAPER_CACHE = {}

def get_paper_by_pmid(pmid: str):
    global _PAPER_CACHE
    if not _PAPER_CACHE and RAW_DATA_CSV.exists():
        with open(RAW_DATA_CSV, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                _PAPER_CACHE[str(row.get("PMID", "")).strip()] = row
    return _PAPER_CACHE.get(str(pmid).strip())

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/validation")
def validation_view():
    return render_template("validation.html")

@app.route("/evaluation")
def evaluation_view():
    return render_template("evaluation.html")

@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.get_json() or {}
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "Empty query provided"}), 400

    top_k = int(data.get("top_k", 5))
    mode = data.get("mode", "hybrid")
    min_year = data.get("min_year")
    max_year = data.get("max_year")
    keyword_filter = data.get("keyword_filter")
    author_filter = data.get("author_filter")

    if min_year:
        try:
            min_year = int(min_year)
        except ValueError:
            min_year = None
    if max_year:
        try:
            max_year = int(max_year)
        except ValueError:
            max_year = None

    # Step 1: Hybrid Retrieval
    retrieved_docs = retriever.retrieve(
        query=query,
        top_k=top_k,
        mode=mode,
        min_year=min_year,
        max_year=max_year,
        keyword_filter=keyword_filter,
        author_filter=author_filter,
    )

    # Step 2: RAG Generation
    synthesis = rag_engine.generate_response(query, retrieved_docs)

    # Step 3: Grounding & Citation Verification
    grounding_info = grounding_verifier.verify_grounding(synthesis, retrieved_docs)

    return jsonify({
        "query": query,
        "mode": mode,
        "retrieved_count": len(retrieved_docs),
        "results": retrieved_docs,
        "synthesis": synthesis,
        "grounding": grounding_info,
    })

@app.route("/api/fetch_papers", methods=["POST"])
def api_fetch_papers():
    data = request.get_json() or {}
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "Empty query provided"}), 400

    top_k = int(data.get("top_k", 8))
    mode = data.get("mode", "hybrid")
    min_year = data.get("min_year")
    max_year = data.get("max_year")
    keyword_filter = data.get("keyword_filter")
    author_filter = data.get("author_filter")

    if min_year:
        try:
            min_year = int(min_year)
        except ValueError:
            min_year = None
    if max_year:
        try:
            max_year = int(max_year)
        except ValueError:
            max_year = None

    # Step 1: Hybrid Retrieval to fetch research papers
    papers = retriever.retrieve(
        query=query,
        top_k=top_k,
        mode=mode,
        min_year=min_year,
        max_year=max_year,
        keyword_filter=keyword_filter,
        author_filter=author_filter,
    )

    return jsonify({
        "query": query,
        "mode": mode,
        "retrieved_count": len(papers),
        "papers": papers,
    })

@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json() or {}
    message = data.get("message", "").strip()
    history = data.get("history", [])
    selected_pmids = data.get("selected_pmids", [])  # Optional explicit paper targets
    if not message:
        return jsonify({"error": "Empty message provided"}), 400

    top_k = int(data.get("top_k", 5))
    mode = data.get("mode", "hybrid")
    min_year = data.get("min_year")
    max_year = data.get("max_year")
    keyword_filter = data.get("keyword_filter")
    author_filter = data.get("author_filter")

    if min_year:
        try:
            min_year = int(min_year)
        except ValueError:
            min_year = None
    if max_year:
        try:
            max_year = int(max_year)
        except ValueError:
            max_year = None

    retrieved_docs = []

    # If specific PMIDs were selected by the user to query about, use those exact papers!
    if selected_pmids and len(selected_pmids) > 0:
        for pmid in selected_pmids:
            paper = get_paper_by_pmid(str(pmid).strip())
            if paper:
                retrieved_docs.append({
                    "pmid": str(paper.get("PMID", pmid)).strip(),
                    "title": paper.get("Title", "Untitled"),
                    "abstract": paper.get("Abstract", ""),
                    "publication_date": paper.get("Publication Date", ""),
                    "authors": paper.get("Authors", ""),
                    "mesh_terms": paper.get("MeSH Terms", ""),
                    "keywords": paper.get("Keywords", ""),
                    "score": 1.0,
                    "rrf_score": 1.0,
                    "dense_score": 1.0,
                    "bm25_score": 1.0,
                })

    # If no explicit papers targeted, run hybrid retrieval on the prompt
    if not retrieved_docs:
        retrieval_query = message
        if history and len(message.split()) < 6:
            last_user_msgs = [h.get("content", "") for h in history if h.get("role") == "user"]
            if last_user_msgs:
                retrieval_query = f"{last_user_msgs[-1]} {message}"

        retrieved_docs = retriever.retrieve(
            query=retrieval_query,
            top_k=top_k,
            mode=mode,
            min_year=min_year,
            max_year=max_year,
            keyword_filter=keyword_filter,
            author_filter=author_filter,
        )

    # Step 2: Conversational RAG Generation
    response_text = rag_engine.generate_chat_response(
        message=message,
        retrieved_docs=retrieved_docs,
        history=history,
    )

    # Step 3: Grounding & Citation Verification
    grounding_info = grounding_verifier.verify_grounding(response_text, retrieved_docs)

    return jsonify({
        "message": message,
        "response": response_text,
        "retrieved_count": len(retrieved_docs),
        "retrieved_docs": retrieved_docs,
        "grounding": grounding_info,
        "context_mode": "targeted_papers" if selected_pmids else "hybrid_retrieval",
    })

@app.route("/api/validation", methods=["GET"])
def api_validation():
    if not VALIDATION_RESULTS_JSON.exists():
        return jsonify({"error": "Validation results not yet generated"}), 404

    with open(VALIDATION_RESULTS_JSON, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Optional query filter
    status_filter = request.args.get("status")  # accepted, flagged, rejected
    search_q = request.args.get("q", "").lower().strip()

    records_list = list(data.get("records", {}).values())

    if status_filter and status_filter.lower() != "all":
        records_list = [r for r in records_list if r.get("status", "").lower() == status_filter.lower()]

    if search_q:
        records_list = [
            r for r in records_list
            if search_q in str(r.get("pmid", "")).lower() or search_q in str(r.get("title", "")).lower()
        ]

    return jsonify({
        "summary": data.get("summary", {}),
        "total_filtered": len(records_list),
        "records": records_list[:200],  # Return up to 200 for fast UI rendering
    })

@app.route("/api/evaluation", methods=["GET"])
def api_evaluation():
    if not EVALUATION_RESULTS_JSON.exists():
        return jsonify({"error": "Evaluation results not yet generated"}), 404

    with open(EVALUATION_RESULTS_JSON, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/api/paper/<pmid>", methods=["GET"])
def api_paper(pmid):
    paper = get_paper_by_pmid(pmid)
    if not paper:
        return jsonify({"error": f"Paper PMID {pmid} not found"}), 404
    return jsonify(paper)

def create_app():
    return app

if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=False)
