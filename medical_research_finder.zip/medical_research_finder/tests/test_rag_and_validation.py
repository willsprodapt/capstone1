import unittest
import json
import csv
from pathlib import Path

from src.config import (
    RAW_DATA_CSV,
    VALIDATED_DATA_CSV,
    VALIDATION_RESULTS_JSON,
    CHUNKS_JSON,
)
from src.retriever import HybridRetriever
from src.rag_engine import RAGEngine
from src.grounding_verifier import GroundingVerifier
from src.data_validator import DatasetValidator
from src.chunker import DocumentChunker

class TestMedicalRAGAndValidation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.retriever = HybridRetriever()
        cls.rag_engine = RAGEngine()
        cls.verifier = GroundingVerifier()
        cls.validator = DatasetValidator()

    def test_01_raw_dataset_count_and_schema(self):
        """Verify the raw dataset has exactly 2,000 records with required fields."""
        self.assertTrue(RAW_DATA_CSV.exists(), "Raw PubMed CSV must exist")
        with open(RAW_DATA_CSV, "r", encoding="utf-8") as f:
            reader = list(csv.DictReader(f))
            self.assertEqual(len(reader), 2000, "Dataset must have exactly 2,000 records")
            required_fields = ["PMID", "Title", "Abstract", "Authors", "Publication Date", "MeSH Terms", "Keywords"]
            for field in required_fields:
                self.assertIn(field, reader[0], f"Required field {field} missing from dataset")

    def test_02_validation_pipeline_categorization(self):
        """Verify deterministic and LLM validation correctly identifies anomalies and categorizes records."""
        # Test duplicate detection
        seen = set(["11111111"])
        dup_rec = {"PMID": "11111111", "Title": "Valid Title Here", "Abstract": "A" * 80, "Publication Date": "2023-01-01"}
        res_dup = self.validator.run_deterministic_validation(dup_rec, seen)
        self.assertTrue(res_dup["is_duplicate"])
        self.assertFalse(res_dup["pmid_valid"])

        # Test missing abstract
        no_ab_rec = {"PMID": "22222222", "Title": "Valid Title Here", "Abstract": "", "Publication Date": "2023-01-01"}
        res_no_ab = self.validator.run_deterministic_validation(no_ab_rec, set())
        self.assertFalse(res_no_ab["abstract_valid"])

        # Test invalid date
        bad_date_rec = {"PMID": "33333333", "Title": "Valid Title Here", "Abstract": "A" * 80, "Publication Date": "9999-99-99"}
        res_bad_date = self.validator.run_deterministic_validation(bad_date_rec, set())
        self.assertFalse(res_bad_date["date_valid"])

    def test_03_chunk_provenance_preservation(self):
        """Verify chunks retain chunk_id, pmid, title, publication date, and source_document_id."""
        chunker = DocumentChunker()
        sample_doc = {
            "PMID": "38291024",
            "Title": "Trial of Bivalent mRNA Booster in High Risk Cohort",
            "Abstract": "This multi-center randomized clinical trial evaluated immunogenicity and safety. Neutralizing antibody titers were significantly higher.",
            "Publication Date": "2023-06-15",
            "Authors": "Johnson M; Miller T",
            "MeSH Terms": "Vaccines, mRNA; COVID-19",
            "Keywords": "mRNA; booster",
        }
        chunks = chunker.chunk_document(sample_doc)
        self.assertGreaterEqual(len(chunks), 1)
        for c in chunks:
            self.assertEqual(c["pmid"], "38291024")
            self.assertEqual(c["title"], sample_doc["Title"])
            self.assertEqual(c["publication_date"], "2023-06-15")
            self.assertEqual(c["source_document_id"], "38291024")
            self.assertTrue(c["chunk_id"].startswith("38291024_"))

    def test_04_rag_context_contains_valid_pmids(self):
        """Verify context construction strictly formats valid research records with PMIDs."""
        dummy_docs = [
            {"pmid": "10000001", "title": "Paper 1", "publication_date": "2022-01-01", "abstract": "Study 1 abstract", "authors": "Author A", "mesh_terms": "M1", "keywords": "K1"},
            {"pmid": "10000002", "title": "Paper 2", "publication_date": "2023-05-01", "abstract": "Study 2 abstract", "authors": "Author B", "mesh_terms": "M2", "keywords": "K2"},
        ]
        context = self.rag_engine.build_context(dummy_docs)
        self.assertIn("[DOCUMENT 1]", context)
        self.assertIn("PMID: 10000001", context)
        self.assertIn("[DOCUMENT 2]", context)
        self.assertIn("PMID: 10000002", context)

    def test_05_grounding_verification_detects_unsupported_claims(self):
        """Verify grounding verifier flags claims that cite nonexistent papers or make unsupported claims."""
        dummy_docs = [
            {"pmid": "12345678", "title": "Safety and Efficacy of mRNA Vaccine", "abstract": "The trial demonstrated a 95% reduction in symptomatic infection.", "publication_date": "2023-01-01"}
        ]
        # Text with valid citation and an unsupported hallucinated citation
        test_text = (
            "The study reported a 95% reduction in symptomatic infection [PMID: 12345678].\n"
            "Another paper claimed a 100% cure rate for terminal cancer [PMID: 99999999]."
        )
        res = self.verifier.verify_grounding(test_text, dummy_docs)
        self.assertGreater(res["unsupported_claim_rate"], 0.0)
        # Check that PMID 99999999 is flagged
        flagged = [c for c in res["claims"] if "99999999" in str(c.get("citation", "")) or "99999999" in c.get("warning", "")]
        self.assertTrue(len(flagged) > 0, "Non-retrieved PMID 99999999 must be flagged")
        self.assertFalse(flagged[0]["supported"])

    def test_06_insufficient_evidence_handling(self):
        """Verify that empty retrieved context results in an explicit 'insufficient evidence' response."""
        resp = self.rag_engine.generate_response("Question with zero evidence", [])
        self.assertIn("insufficient to answer", resp.lower())

    def test_07_fallback_retrieval_produces_valid_context(self):
        """Verify that fallback mode (BM25 only) executes and produces valid retrieved documents."""
        # Using a BM25 retrieval mode
        if Path(CHUNKS_JSON).exists():
            self.retriever.load_or_build_index()
            results = self.retriever.retrieve("mRNA vaccine respiratory", top_k=3, mode="bm25")
            self.assertGreaterEqual(len(results), 1)
            self.assertTrue(results[0]["pmid"].isdigit())

    def test_08_no_hallucinated_citations_outside_kb(self):
        """Verify provenance rule: verifier catches any citation outside retrieved documents."""
        dummy_docs = [
            {"pmid": "30000001", "title": "Study on Diabetes", "abstract": "Significant glycemic improvement observed.", "publication_date": "2023-01-01"}
        ]
        fake_text = "Metformin was shown to eradicate type 1 diabetes completely [PMID: 88888888]."
        res = self.verifier.verify_grounding(fake_text, dummy_docs)
        self.assertEqual(res["supported_claim_rate"], 0.0)
        self.assertEqual(len(res["claims"]), 1)
        self.assertFalse(res["claims"][0]["supported"])

if __name__ == "__main__":
    unittest.main()
