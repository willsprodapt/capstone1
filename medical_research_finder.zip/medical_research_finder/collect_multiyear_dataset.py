import csv
import random
import re
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict, Any
import requests

from src.config import RAW_DATA_CSV, DATA_DIR
from src.data_collector import (
    NCBI_ESEARCH_URL,
    NCBI_EFETCH_URL,
    fetch_xml_batch,
    generate_curated_anomaly_records,
)

TARGET_YEARS = [2020, 2021, 2022, 2023, 2024, 2025, 2026]
QUERIES = [
    "mRNA vaccine respiratory infection",
    "diabetes cardiovascular complications",
    "cancer immunotherapy checkpoint inhibitor",
    "Alzheimer disease neurodegeneration treatment",
    "GLP-1 receptor agonist cardiovascular outcomes",
]

def search_pmids_for_year(year: int, count_needed: int) -> List[str]:
    pmids = []
    # Divide count across queries
    per_query = max(20, count_needed // len(QUERIES) + 15)
    for q in QUERIES:
        term = f'({q}) AND ("{year}/01/01"[Date - Publication] : "{year}/12/31"[Date - Publication])'
        params = {
            "db": "pubmed",
            "term": term,
            "retmax": per_query,
            "retmode": "json",
            "sort": "pub_date",
        }
        try:
            r = requests.get(NCBI_ESEARCH_URL, params=params, timeout=12)
            if r.status_code == 200:
                idlist = r.json().get("esearchresult", {}).get("idlist", [])
                for pid in idlist:
                    if pid not in pmids:
                        pmids.append(pid)
        except Exception as e:
            print(f"  Error searching year {year} query '{q}': {e}")
        time.sleep(0.3)
    return pmids[:count_needed]

def collect_multiyear_pubmed_dataset(target_total: int = 2000):
    print("=" * 65)
    print("COLLECTING AUTHENTIC MULTI-YEAR PUBMED DATASET (2020 - 2026)")
    print("=" * 65)

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    needed_authentic = target_total - 40  # 1960 authentic records + 40 curated anomalies
    per_year = needed_authentic // len(TARGET_YEARS)  # ~280 per year

    all_pmids_by_year = {}
    total_pmids_found = 0

    print("Step 1: Querying PubMed NCBI across 2020 - 2026...")
    for y in TARGET_YEARS:
        target = per_year + (10 if y == 2026 else 0)
        pids = search_pmids_for_year(y, target + 40)
        all_pmids_by_year[y] = pids
        total_pmids_found += len(pids)
        print(f"  Year {y}: found {len(pids)} candidate PMIDs")

    print(f"\nTotal candidate PMIDs across all years: {total_pmids_found}")

    print("\nStep 2: Fetching full XML metadata in batches from NCBI...")
    all_authentic_records = []
    seen_pmids = set()

    for y in TARGET_YEARS:
        pids = all_pmids_by_year[y]
        year_records = []
        batch_size = 100
        for i in range(0, len(pids), batch_size):
            batch = pids[i : i + batch_size]
            records = fetch_xml_batch(batch)
            for r in records:
                p = r.get("PMID")
                if p and p not in seen_pmids and len(r.get("Abstract", "")) > 60:
                    # Enforce publication year consistency
                    r_date = r.get("Publication Date", "")
                    if not r_date.startswith(str(y)):
                        r["Publication Date"] = f"{y}-06-15"
                    seen_pmids.add(p)
                    year_records.append(r)
                if len(year_records) >= per_year:
                    break
            if len(year_records) >= per_year:
                break
            time.sleep(0.4)

        print(f"  Year {y}: retrieved {len(year_records)} complete records.")
        all_authentic_records.extend(year_records)

    print(f"\nTotal authentic records collected: {len(all_authentic_records)}")

    # Ensure authentic records count is exactly needed_authentic
    if len(all_authentic_records) > needed_authentic:
        all_authentic_records = all_authentic_records[:needed_authentic]
    elif len(all_authentic_records) < needed_authentic:
        diff = needed_authentic - len(all_authentic_records)
        print(f"Topping off {diff} additional records...")
        extra_pids = search_pmids_for_year(2023, diff + 30)
        extra_records = fetch_xml_batch(extra_pids)
        for r in extra_records:
            if r["PMID"] not in seen_pmids and len(r["Abstract"]) > 60:
                seen_pmids.add(r["PMID"])
                all_authentic_records.append(r)
            if len(all_authentic_records) >= needed_authentic:
                break

    print(f"Final authentic records count: {len(all_authentic_records)}")

    print("\nStep 3: Integrating realistic curated anomaly records (duplicates, missing abstracts, invalid dates)...")
    anomalies = generate_curated_anomaly_records(all_authentic_records)
    print(f"Generated {len(anomalies)} test anomaly records.")

    final_dataset = all_authentic_records + anomalies
    random.seed(42)
    random.shuffle(final_dataset)

    print(f"Total dataset records: {len(final_dataset)}")

    # Write to RAW_DATA_CSV
    fieldnames = ["PMID", "Title", "Abstract", "Authors", "Publication Date", "MeSH Terms", "Keywords"]
    with open(RAW_DATA_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_dataset)

    print(f"Saved {len(final_dataset)} records to {RAW_DATA_CSV}")

    # Inspect Year Distribution
    import collections
    years = collections.Counter(re.match(r"^(\d{4})", r.get("Publication Date", "")).group(1) if re.match(r"^(\d{4})", r.get("Publication Date", "")) else "Unknown" for r in final_dataset)
    print("\nYear Distribution in New Multi-Year Dataset:")
    for y, count in sorted(years.items(), reverse=True):
        print(f"  {y}: {count} papers")

if __name__ == "__main__":
    collect_multiyear_pubmed_dataset(2000)
