import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.retriever import HybridRetriever
from src.rag_engine import RAGEngine
from src.grounding_verifier import GroundingVerifier

def verify_all_fallbacks():
    print("=" * 65)
    print("DEMONSTRATION & VERIFICATION OF FALLBACK MECHANISMS")
    print("=" * 65)

    retriever = HybridRetriever()
    retriever.load_or_build_index()
    rag = RAGEngine()
    verifier = GroundingVerifier()

    test_query = "effectiveness of mRNA vaccines against respiratory infections"

    # 1. Primary Hybrid Mode (BM25 + Dense -> RRF)
    print("\n--- [1] PRIMARY RETRIEVAL: Hybrid RRF (BM25 + Dense) ---")
    hybrid_res = retriever.retrieve(test_query, top_k=3, mode="hybrid")
    print(f"Hybrid retrieval returned {len(hybrid_res)} papers.")
    for p in hybrid_res:
        print(f"  - PMID: {p['pmid']} | RRF: {p['rrf_score']} | Dense: {p['dense_score']} | BM25: {p['bm25_score']}")

    # 2. Retrieval Fallback 1: BM25-Only Fallback
    print("\n--- [2] RETRIEVAL FALLBACK 1: BM25-Only Mode ---")
    print("(Simulates scenario where dense vector embeddings/API are unavailable)")
    bm25_res = retriever.retrieve(test_query, top_k=3, mode="bm25")
    print(f"BM25-only fallback returned {len(bm25_res)} papers:")
    for p in bm25_res:
        print(f"  - PMID: {p['pmid']} | BM25 Score: {p['bm25_score']} | Title: {p['title'][:60]}...")
    assert len(bm25_res) > 0, "BM25 fallback must return valid papers"

    # 3. Retrieval Fallback 2: Dense-Only Fallback
    print("\n--- [3] RETRIEVAL FALLBACK 2: Dense-Only Vector Mode ---")
    print("(Simulates scenario where sparse keyword matching has no exact vocabulary overlap)")
    dense_res = retriever.retrieve(test_query, top_k=3, mode="dense")
    print(f"Dense-only fallback returned {len(dense_res)} papers:")
    for p in dense_res:
        print(f"  - PMID: {p['pmid']} | Dense Cosine: {p['dense_score']} | Title: {p['title'][:60]}...")
    assert len(dense_res) > 0, "Dense fallback must return valid papers"

    # 4. Automated Degraded Fallback: dense vector temporarily None
    print("\n--- [4] AUTOMATED DEGRADATION FALLBACK ---")
    print("(Retriever dynamically detects missing/failed embeddings and falls back to BM25)")
    saved_embs = retriever.embeddings
    retriever.embeddings = None  # Simulate vector engine failure / disconnection
    degraded_res = retriever.retrieve(test_query, top_k=3, mode="hybrid")
    print(f"Automatic graceful fallback returned {len(degraded_res)} papers without crashing:")
    for p in degraded_res:
        print(f"  - PMID: {p['pmid']} | Score: {p['score']} | Title: {p['title'][:60]}...")
    retriever.embeddings = saved_embs  # Restore

    # 5. RAG Insufficient Evidence Fallback
    print("\n--- [5] RAG INSUFFICIENT EVIDENCE FALLBACK ---")
    print("(When 0 evidence papers exist, LLM refuses to hallucinate from pretrained weights)")
    empty_response = rag.generate_response("Quantum computing in astrophysics", [])
    print("RAG Empty Fallback Response:")
    print(empty_response)
    assert "insufficient to answer" in empty_response.lower()

    print("\n" + "=" * 65)
    print("ALL FALLBACK MECHANISMS VERIFIED AND FULLY FUNCTIONAL!")
    print("=" * 65)

if __name__ == "__main__":
    verify_all_fallbacks()
