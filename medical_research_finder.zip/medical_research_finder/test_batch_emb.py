import requests
import json
import time

GATEWAY_URL = "https://keygateway1.arshnivlabs.com"
LEARNER_KEY = "pubatch11"
headers = {
    "Authorization": f"Bearer {LEARNER_KEY}",
    "Content-Type": "application/json",
}

# Test batch embedding
batch = [f"Medical sentence {i}: Clinical trial evaluation for therapy." for i in range(16)]
t0 = time.time()
res = requests.post(f"{GATEWAY_URL}/v1/embeddings", headers=headers, json={"input": batch}, timeout=30)
t1 = time.time()
print("Status:", res.status_code, f"Time: {t1-t0:.2f}s")
data = res.json()
if "data" in data:
    print(f"Received {len(data['data'])} embeddings, dim {len(data['data'][0]['embedding'])}")
else:
    print("Error:", data)
