// State Management
let currentMode = 'fetch'; // 'fetch' or 'chat'
let fetchedPapers = [];
let selectedPapersMap = new Map(); // pmid -> paper object
let conversationHistory = [];

document.addEventListener('DOMContentLoaded', () => {
  const fetchInput = document.getElementById('fetchQueryInput');
  const chatInput = document.getElementById('chatInput');

  if (fetchInput) {
    fetchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        performFetch();
      }
    });
  }

  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        submitChatMessage();
      }
    });

    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    });
  }

  // Pre-fetch default query on initial load
  performFetch();
});

// ==========================================
// MODE NAVIGATION (Separation of 1 & 2)
// ==========================================
function switchMode(mode) {
  currentMode = mode;
  const tabFetch = document.getElementById('tabFetchMode');
  const tabChat = document.getElementById('tabChatMode');
  const fetchSec = document.getElementById('fetchSection');
  const chatSec = document.getElementById('chatSection');

  if (mode === 'fetch') {
    tabFetch.classList.add('active');
    tabChat.classList.remove('active');
    fetchSec.classList.remove('hidden');
    chatSec.classList.add('hidden');
  } else {
    tabFetch.classList.remove('active');
    tabChat.classList.add('active');
    fetchSec.classList.add('hidden');
    chatSec.classList.remove('hidden');
    renderActiveContext();
    scrollToBottom();
  }
}

// ==========================================
// FUNCTIONALITY 1: FETCH RESEARCH PAPERS
// ==========================================
function setFetchQuery(text) {
  const input = document.getElementById('fetchQueryInput');
  if (input) {
    input.value = text;
    performFetch();
  }
}

async function performFetch() {
  const query = document.getElementById('fetchQueryInput').value.trim();
  if (!query) return;

  const btn = document.getElementById('fetchBtn');
  const btnText = document.getElementById('fetchBtnText');
  const spinner = document.getElementById('fetchSpinner');
  const errorBanner = document.getElementById('fetchErrorBanner');
  const container = document.getElementById('fetchedResultsContainer');

  const mode = document.getElementById('fetchMode').value;
  const topK = parseInt(document.getElementById('fetchTopK').value, 10);
  const minYear = document.getElementById('fetchMinYear').value ? parseInt(document.getElementById('fetchMinYear').value, 10) : null;
  const keywordFilter = document.getElementById('fetchKeywordFilter').value.trim() || null;

  btn.disabled = true;
  btnText.textContent = 'Fetching Papers...';
  spinner.classList.remove('hidden');
  errorBanner.classList.add('hidden');

  try {
    const payload = {
      query: query,
      mode: mode,
      top_k: topK,
      min_year: minYear,
      keyword_filter: keywordFilter,
    };

    const res = await fetch('/api/fetch_papers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to fetch research papers');
    }

    const data = await res.json();
    fetchedPapers = data.papers || [];

    // Automatically select the top 3 papers by default for convenience
    selectedPapersMap.clear();
    fetchedPapers.slice(0, 3).forEach(p => selectedPapersMap.set(p.pmid, p));

    renderFetchedPapers();
    container.classList.remove('hidden');
    updateSelectionBadges();

  } catch (err) {
    errorBanner.textContent = `Fetch Error: ${err.message}`;
    errorBanner.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btnText.textContent = 'Fetch Research Papers';
    spinner.classList.add('hidden');
  }
}

function renderFetchedPapers() {
  const list = document.getElementById('fetchedPapersList');
  const countSpan = document.getElementById('fetchedCount');
  countSpan.textContent = fetchedPapers.length;

  if (fetchedPapers.length === 0) {
    list.innerHTML = '<p class="text-muted" style="grid-column: 1/-1; text-align: center; padding: 2rem;">No matching research papers found in the knowledge base.</p>';
    return;
  }

  list.innerHTML = fetchedPapers.map((p, idx) => {
    const isSelected = selectedPapersMap.has(p.pmid);
    return `
      <div class="paper-card-selectable ${isSelected ? 'selected' : ''}" id="card_${p.pmid}">
        <div class="card-top-row">
          <label class="select-checkbox-label">
            <input type="checkbox" ${isSelected ? 'checked' : ''} onchange="togglePaperSelection('${p.pmid}', this.checked)">
            <span>Select for Chat</span>
          </label>
          <span class="badge badge-info" onclick="openPaperModal('${p.pmid}')" style="cursor: pointer;">
            PMID: ${p.pmid}
          </span>
        </div>

        <div class="paper-title" onclick="openPaperModal('${p.pmid}')">
          ${idx + 1}. ${escapeHtml(p.title)}
        </div>

        <div class="paper-meta" style="font-size: 0.76rem; color: var(--text-muted); margin-bottom: 0.4rem;">
          <strong>Date:</strong> ${p.publication_date || 'N/A'} | 
          <strong>Authors:</strong> ${escapeHtml(p.authors || 'Unknown Authors')}
        </div>

        <div class="paper-snippet">
          ${escapeHtml(p.abstract)}
        </div>

        <div class="card-bottom-actions">
          <div class="score-pills">
            <span class="score-pill" title="RRF Score">RRF: ${p.rrf_score}</span>
            <span class="score-pill" title="Dense Cosine">Dense: ${p.dense_score}</span>
          </div>

          <div style="display: flex; gap: 0.4rem;">
            <button class="btn btn-sm btn-outline" onclick="openPaperModal('${p.pmid}')">
              Full Abstract
            </button>
            <button class="btn btn-sm btn-primary" onclick="chatWithSinglePaper('${p.pmid}')">
              💬 Ask This Paper
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function togglePaperSelection(pmid, checked) {
  const paper = fetchedPapers.find(p => p.pmid === pmid);
  if (checked && paper) {
    selectedPapersMap.set(pmid, paper);
  } else {
    selectedPapersMap.delete(pmid);
  }

  const card = document.getElementById(`card_${pmid}`);
  if (card) {
    if (checked) card.classList.add('selected');
    else card.classList.remove('selected');
  }

  updateSelectionBadges();
}

function selectAllPapers(selectAll) {
  if (selectAll) {
    fetchedPapers.forEach(p => selectedPapersMap.set(p.pmid, p));
  } else {
    selectedPapersMap.clear();
  }
  renderFetchedPapers();
  updateSelectionBadges();
}

function updateSelectionBadges() {
  const count = selectedPapersMap.size;
  document.getElementById('selectedCountBadge').textContent = count;
  document.getElementById('navContextBadge').textContent = `${count} Selected`;
}

function chatWithSinglePaper(pmid) {
  selectedPapersMap.clear();
  const paper = fetchedPapers.find(p => p.pmid === pmid);
  if (paper) {
    selectedPapersMap.set(pmid, paper);
  }
  updateSelectionBadges();
  switchMode('chat');
}

function proceedToChatWithSelected() {
  if (selectedPapersMap.size === 0) {
    alert("Please select at least one paper using the checkboxes to chat with.");
    return;
  }
  switchMode('chat');
}

// =======================================================
// FUNCTIONALITY 2: PROMPT / CHAT WITH THE RESEARCH PAPERS
// =======================================================
function renderActiveContext() {
  const badgesContainer = document.getElementById('activeContextBadges');
  const sidebarList = document.getElementById('activeContextPapersList');
  const sidebarCountBadge = document.getElementById('activePapersCountBadge');

  const selectedList = Array.from(selectedPapersMap.values());
  sidebarCountBadge.textContent = `${selectedList.length} Papers`;

  if (selectedList.length === 0) {
    badgesContainer.innerHTML = '<span class="badge badge-info">All Retrieved Papers / General Knowledge Base</span>';
    sidebarList.innerHTML = `
      <div class="empty-evidence">
        <div style="font-size: 2rem; margin-bottom: 0.5rem;">🌐</div>
        <p>No papers explicitly targeted. Your prompts will search across the entire 2,000-paper knowledge base.</p>
      </div>
    `;
    return;
  }

  badgesContainer.innerHTML = selectedList.map(p => `
    <span class="context-badge-item">
      <span>PMID: ${p.pmid}</span>
      <button class="remove-btn" onclick="removeContextPaper('${p.pmid}')" title="Remove Paper">&times;</button>
    </span>
  `).join('');

  sidebarList.innerHTML = selectedList.map((p, idx) => `
    <div class="paper-card" style="padding: 0.85rem 1rem;">
      <div class="paper-card-header">
        <div class="paper-title" onclick="openPaperModal('${p.pmid}')" style="font-size: 0.88rem;">
          ${idx + 1}. ${escapeHtml(p.title)}
        </div>
        <span class="badge badge-info" onclick="openPaperModal('${p.pmid}')" style="cursor: pointer; font-size: 0.7rem;">
          PMID: ${p.pmid}
        </span>
      </div>
      <div class="paper-meta" style="font-size: 0.72rem; margin-bottom: 0.4rem;">
        <strong>Date:</strong> ${p.publication_date || 'N/A'} | <strong>Authors:</strong> ${escapeHtml(p.authors || 'Unknown')}
      </div>
      <div class="paper-snippet" style="font-size: 0.78rem; -webkit-line-clamp: 2;">
        ${escapeHtml(p.abstract)}
      </div>
      <div class="paper-footer" style="margin-top: 0.5rem;">
        <button class="btn btn-sm btn-outline" onclick="openPaperModal('${p.pmid}')" style="font-size: 0.72rem; padding: 0.2rem 0.5rem;">
          Inspect Full Abstract
        </button>
      </div>
    </div>
  `).join('');
}

function removeContextPaper(pmid) {
  selectedPapersMap.delete(pmid);
  updateSelectionBadges();
  renderActiveContext();
  const card = document.getElementById(`card_${pmid}`);
  if (card) {
    card.classList.remove('selected');
    const cb = card.querySelector('input[type="checkbox"]');
    if (cb) cb.checked = false;
  }
}

function clearSelectedContext() {
  selectedPapersMap.clear();
  updateSelectionBadges();
  renderActiveContext();
  renderFetchedPapers();
}

function sendChatPrompt(text) {
  const chatInput = document.getElementById('chatInput');
  if (chatInput) {
    chatInput.value = text;
    submitChatMessage();
  }
}

async function submitChatMessage() {
  const chatInput = document.getElementById('chatInput');
  const text = chatInput.value.trim();
  if (!text) return;

  const sendBtn = document.getElementById('sendBtn');
  const sendIcon = document.getElementById('sendIcon');
  const sendSpinner = document.getElementById('sendSpinner');
  const chatMessages = document.getElementById('chatMessages');

  // Clear input
  chatInput.value = '';
  chatInput.style.height = 'auto';

  // Append user message
  appendUserMessage(text);

  // Append typing indicator
  const indicatorId = 'indicator_' + Date.now();
  appendTypingIndicator(indicatorId);
  scrollToBottom();

  sendBtn.disabled = true;
  sendIcon.classList.add('hidden');
  sendSpinner.classList.remove('hidden');

  try {
    const selectedPMIDs = Array.from(selectedPapersMap.keys());
    const payload = {
      message: text,
      selected_pmids: selectedPMIDs,
      history: conversationHistory,
      top_k: 5,
      mode: 'hybrid',
    };

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Chat synthesis error');
    }

    const data = await res.json();
    removeElement(indicatorId);

    // Append Assistant response
    appendAssistantMessage(data);

    // Update conversation history
    conversationHistory.push({ role: 'user', content: text });
    conversationHistory.push({ role: 'assistant', content: data.response });

  } catch (err) {
    removeElement(indicatorId);
    appendErrorMessage(`Error: ${err.message}`);
  } finally {
    sendBtn.disabled = false;
    sendIcon.classList.remove('hidden');
    sendSpinner.classList.add('hidden');
    scrollToBottom();
  }
}

function appendUserMessage(text) {
  const chatMessages = document.getElementById('chatMessages');
  const row = document.createElement('div');
  row.className = 'message-row user';
  row.innerHTML = `
    <div class="avatar">👤</div>
    <div class="message-bubble">
      <div class="message-meta">
        <span class="author-name">You</span>
        <span>${formatTime()}</span>
      </div>
      <div class="message-content">
        <p>${escapeHtml(text)}</p>
      </div>
    </div>
  `;
  chatMessages.appendChild(row);
}

function appendTypingIndicator(id) {
  const chatMessages = document.getElementById('chatMessages');
  const row = document.createElement('div');
  row.id = id;
  row.className = 'message-row assistant';
  row.innerHTML = `
    <div class="avatar">🧬</div>
    <div class="message-bubble">
      <div class="typing-indicator">
        <span class="spinner" style="border-top-color: var(--primary); border-color: rgba(13,148,136,0.2);"></span>
        <span>Synthesizing answer from research papers...</span>
      </div>
    </div>
  `;
  chatMessages.appendChild(row);
}

function appendAssistantMessage(data) {
  const chatMessages = document.getElementById('chatMessages');
  const grounding = data.grounding || {};
  const papers = data.retrieved_docs || [];

  let rawText = data.response || '';
  let renderedHtml = marked.parse(rawText);

  // Clickable PMID badges
  renderedHtml = renderedHtml.replace(
    /\[(?:PMID:?\s*|pmid\s*)([0-9]+)\]/gi,
    (match, pmid) => `<a href="javascript:void(0)" onclick="openPaperModal('${pmid}')" class="pmid-badge">[PMID: ${pmid}]</a>`
  );

  const score = grounding.grounding_score !== undefined ? grounding.grounding_score : 'N/A';
  const papersUsed = grounding.source_papers_used || 0;
  const verifiedCits = grounding.citations_verified || '0/0';
  const supportedPercent = Math.round((grounding.supported_claim_rate || 0) * 100);
  const isGrounded = (grounding.unsupported_claim_rate || 0) === 0;

  const claims = grounding.claims || [];
  let claimsHtml = '';
  if (claims.length > 0) {
    claimsHtml = `
      <div style="margin-top: 0.5rem; display: flex; flex-direction: column; gap: 0.4rem;">
        ${claims.map(c => `
          <div class="claim-item ${c.supported ? 'supported' : 'unsupported'}" style="font-size: 0.78rem; padding: 0.5rem 0.75rem;">
            <div>"${escapeHtml(c.claim)}"</div>
            <div style="display: flex; justify-content: space-between; margin-top: 0.25rem;">
              <span><strong>Citation:</strong> ${c.citation}</span>
              <span><strong>Score:</strong> <code>${c.evidence_score}</code> <span class="badge ${c.supported ? 'badge-success' : 'badge-danger'}">${c.supported ? 'Supported' : 'Unsupported'}</span></span>
            </div>
            ${c.warning ? `<div style="color: var(--danger); font-size: 0.72rem; margin-top: 0.2rem;">⚠️ ${c.warning}</div>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  const row = document.createElement('div');
  row.className = 'message-row assistant';
  row.innerHTML = `
    <div class="avatar">🧬</div>
    <div class="message-bubble">
      <div class="message-meta">
        <span class="author-name">PubMed Research Copilot</span>
        <span>${formatTime()}</span>
      </div>

      <div class="bubble-grounding-bar">
        <div class="bubble-grounding-stats">
          <span>🎯 Grounding Score: <strong class="grounding-tag">${score}</strong></span>
          <span>📚 Papers Used: <strong>${papersUsed}</strong></span>
          <span>✅ Citations: <strong>${verifiedCits}</strong></span>
          <span>🛡️ Supported: <strong>${supportedPercent}%</strong></span>
        </div>
        <span class="badge ${isGrounded ? 'badge-success' : 'badge-warning'}">
          ${isGrounded ? 'Grounded & Verified' : 'Flagged Claims'}
        </span>
      </div>

      ${!isGrounded ? `
        <div class="alert alert-warning" style="margin-bottom: 0.75rem; padding: 0.6rem 0.8rem; font-size: 0.8rem;">
          <strong>Notice:</strong> One or more claims generated were not fully supported by retrieved abstracts.
        </div>
      ` : ''}

      <div class="message-content markdown-body">
        ${renderedHtml}
      </div>

      <details class="evidence-accordion">
        <summary>🔍 Inspect ${papers.length} Source Papers & Grounding Verification</summary>
        <div class="accordion-content">
          <div style="font-weight: 600; margin-bottom: 0.4rem; color: var(--text-muted);">Factual Claims Verification (${claims.length} claims):</div>
          ${claimsHtml || '<p class="text-muted">No discrete claims parsed.</p>'}

          <div style="font-weight: 600; margin-top: 0.75rem; margin-bottom: 0.4rem; color: var(--text-muted);">Source Papers:</div>
          <div style="display: flex; flex-direction: column; gap: 0.4rem;">
            ${papers.map((p, i) => `
              <div style="background: var(--bg-subtle); padding: 0.5rem 0.75rem; border-radius: 4px; font-size: 0.78rem;">
                <strong>[Doc ${i+1}]</strong> <a href="javascript:void(0)" onclick="openPaperModal('${p.pmid}')" style="color: var(--accent); font-weight: 600;">${escapeHtml(p.title)}</a>
                <div style="color: var(--text-muted); font-size: 0.72rem; margin-top: 2px;">
                  PMID: ${p.pmid} | Date: ${p.publication_date}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </details>
    </div>
  `;
  chatMessages.appendChild(row);
}

function appendErrorMessage(msg) {
  const chatMessages = document.getElementById('chatMessages');
  const row = document.createElement('div');
  row.className = 'message-row assistant';
  row.innerHTML = `
    <div class="avatar">⚠️</div>
    <div class="message-bubble" style="border-color: var(--danger); background: var(--danger-light);">
      <div class="message-content" style="color: var(--danger); font-size: 0.88rem;">
        <strong>Error:</strong> ${escapeHtml(msg)}
      </div>
    </div>
  `;
  chatMessages.appendChild(row);
}

async function openPaperModal(pmid) {
  try {
    const res = await fetch(`/api/paper/${pmid}`);
    if (!res.ok) {
      alert(`Paper with PMID ${pmid} could not be retrieved from knowledge base.`);
      return;
    }
    const paper = await res.json();
    document.getElementById('modalTitle').textContent = paper.Title || 'Paper Details';
    document.getElementById('modalPMID').textContent = paper.PMID || pmid;
    document.getElementById('modalDate').textContent = paper['Publication Date'] || 'N/A';
    document.getElementById('modalAuthors').textContent = paper.Authors || 'Unknown Authors';
    document.getElementById('modalMeSH').textContent = paper['MeSH Terms'] || 'None recorded';
    document.getElementById('modalKeywords').textContent = paper.Keywords || 'None recorded';
    document.getElementById('modalAbstract').textContent = paper.Abstract || 'No abstract available.';

    document.getElementById('paperModal').classList.remove('hidden');
  } catch (err) {
    console.error('Failed to open paper modal', err);
  }
}

function closeModal() {
  document.getElementById('paperModal').classList.add('hidden');
}

function scrollToBottom() {
  const chatMessages = document.getElementById('chatMessages');
  if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
}

function formatTime() {
  const now = new Date();
  return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function removeElement(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
