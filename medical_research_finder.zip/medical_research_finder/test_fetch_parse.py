import requests
import xml.etree.ElementTree as ET
import time

def test_fetch_sample():
    queries = [
        "mRNA vaccine respiratory infection",
        "diabetes cardiovascular complications",
        "cancer immunotherapy checkpoint inhibitor",
        "Alzheimer disease neurodegeneration treatment",
    ]
    esearch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    efetch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
    
    all_pmids = set()
    for q in queries:
        params = {"db": "pubmed", "term": q, "retmax": 20, "retmode": "json"}
        r = requests.get(esearch_url, params=params, timeout=10)
        if r.status_code == 200:
            idlist = r.json().get("esearchresult", {}).get("idlist", [])
            all_pmids.update(idlist)
            print(f"Query '{q}': found {len(idlist)} PMIDs")
    
    print(f"Total unique sample PMIDs: {len(all_pmids)}")
    sample_ids = list(all_pmids)[:10]
    
    fetch_params = {"db": "pubmed", "id": ",".join(sample_ids), "retmode": "xml"}
    fr = requests.get(efetch_url, params=fetch_params, timeout=15)
    print("Fetch status:", fr.status_code)
    root = ET.fromstring(fr.content)
    articles = root.findall(".//PubmedArticle")
    print(f"Successfully parsed {len(articles)} XML articles.")
    for a in articles[:2]:
        pmid = a.findtext(".//PMID")
        title = a.findtext(".//ArticleTitle")
        
        # Abstract
        ab_texts = [elem.text for elem in a.findall(".//Abstract/AbstractText") if elem.text]
        abstract = " ".join(ab_texts) if ab_texts else ""
        
        # Authors
        authors = []
        for author in a.findall(".//AuthorList/Author"):
            last = author.findtext("LastName") or ""
            fore = author.findtext("ForeName") or ""
            if last or fore:
                authors.append(f"{fore} {last}".strip())
        authors_str = "; ".join(authors)
        
        # Date
        year = a.findtext(".//Journal/JournalIssue/PubDate/Year") or a.findtext(".//DateCompleted/Year") or a.findtext(".//DateRevised/Year") or ""
        month = a.findtext(".//Journal/JournalIssue/PubDate/Month") or "01"
        day = a.findtext(".//Journal/JournalIssue/PubDate/Day") or "01"
        pub_date = f"{year}-{month}-{day}" if year else "Unknown"
        
        # MeSH
        mesh_terms = [m.text for m in a.findall(".//MeshHeading/DescriptorName") if m.text]
        
        # Keywords
        keywords = [k.text for k in a.findall(".//KeywordList/Keyword") if k.text]
        
        print(f"\n--- PMID {pmid} ---")
        print("Title:", title[:80])
        print("Date:", pub_date)
        print("Authors:", authors_str[:60])
        print("Abstract length:", len(abstract))
        print("MeSH count:", len(mesh_terms), mesh_terms[:3])
        print("Keywords count:", len(keywords), keywords[:3])

if __name__ == "__main__":
    test_fetch_sample()
