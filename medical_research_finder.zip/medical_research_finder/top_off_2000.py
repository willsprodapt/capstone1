import csv
import requests
from src.data_collector import fetch_pmids_for_query, fetch_xml_batch
from src.config import RAW_DATA_CSV

def top_off():
    with open(RAW_DATA_CSV, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    print("Current count:", len(rows))
    needed = 2000 - len(rows)
    if needed > 0:
        print(f"Fetching {needed} additional records from NCBI...")
        pmids = fetch_pmids_for_query("hypertension chronic kidney disease treatment", needed + 50)
        existing_pmids = set(r["PMID"] for r in rows)
        new_pmids = [p for p in pmids if p not in existing_pmids][:needed + 30]
        new_records = fetch_xml_batch(new_pmids)
        valid_new = [r for r in new_records if r["Abstract"] and len(r["Abstract"]) > 60][:needed]
        rows.extend(valid_new)
        print("Updated count:", len(rows))

        fieldnames = ["PMID", "Title", "Abstract", "Authors", "Publication Date", "MeSH Terms", "Keywords"]
        with open(RAW_DATA_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved exactly {len(rows)} records to {RAW_DATA_CSV}")

if __name__ == "__main__":
    top_off()
