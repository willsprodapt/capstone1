import json
import requests
from src.config import CHUNKS_JSON, GATEWAY_URL, GATEWAY_HEADERS

with open(CHUNKS_JSON, "r", encoding="utf-8") as f:
    chunks = json.load(f)

print(f"Total chunks: {len(chunks)}")
batch = chunks[300:350]
texts = [c["text"] for c in batch]

print(f"Testing batch 300:350 (length {len(texts)})...")
res = requests.post(
    f"{GATEWAY_URL}/v1/embeddings",
    headers=GATEWAY_HEADERS,
    json={"input": texts},
    timeout=30,
)
print("Status code:", res.status_code)
if res.status_code != 200:
    print("Response text:", res.text)
else:
    print("Success! Got", len(res.json()["data"]), "embeddings")
