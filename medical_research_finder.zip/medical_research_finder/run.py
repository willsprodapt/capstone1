import sys
from pathlib import Path

from src.config import (
    RAW_DATA_CSV,
    VALIDATED_DATA_CSV,
    VALIDATION_RESULTS_JSON,
    CHUNKS_JSON,
    EMBEDDINGS_NPY,
    EVALUATION_RESULTS_JSON,
    HOST,
    PORT,
)

def ensure_pipeline():
    print("=" * 60)
    print("AI-POWERED MEDICAL RESEARCH ABSTRACT FINDER")
    print("Verifying pipeline state and knowledge base...")
    print("=" * 60)

    # 1. Dataset check
    if not RAW_DATA_CSV.exists():
        print("[1/5] Collecting 2,000 PubMed records from NCBI...")
        from src.data_collector import collect_2000_pubmed_records
        collect_2000_pubmed_records(2000)
    else:
        print(f"[1/5] Raw PubMed dataset exists: {RAW_DATA_CSV}")

    # 2. Validation check
    if not VALIDATION_RESULTS_JSON.exists() or not VALIDATED_DATA_CSV.exists():
        print("[2/5] Running Two-Stage Dataset Validation Pipeline...")
        from src.data_validator import DatasetValidator
        validator = DatasetValidator()
        validator.run_full_pipeline()
    else:
        print(f"[2/5] Validated dataset & results exist: {VALIDATION_RESULTS_JSON}")

    # 3. Chunking check
    if not CHUNKS_JSON.exists():
        print("[3/5] Chunking validated records with provenance...")
        from src.chunker import DocumentChunker
        chunker = DocumentChunker()
        chunker.process_and_save()
    else:
        print(f"[3/5] Document chunks exist: {CHUNKS_JSON}")

    # 4. Dense embeddings check
    if not EMBEDDINGS_NPY.exists():
        print("[4/5] Computing dense vector embeddings...")
        from build_embeddings import build_embeddings
        build_embeddings()
    else:
        print(f"[4/5] Dense embeddings matrix exists: {EMBEDDINGS_NPY}")

    # 5. Pre-warm retriever and run evaluator if needed
    if not EVALUATION_RESULTS_JSON.exists():
        print("[5/5] Computing system evaluation benchmark...")
        from src.evaluator import SystemEvaluator
        evaluator = SystemEvaluator()
        evaluator.run_full_evaluation()
    else:
        print(f"[5/5] Evaluation benchmark results exist: {EVALUATION_RESULTS_JSON}")

    print("=" * 60)
    print("All pipeline stages verified. Starting Flask Web Application...")
    print(f"URL: http://127.0.0.1:{PORT}")
    print("=" * 60)

if __name__ == "__main__":
    ensure_pipeline()
    from src.web_app import app
    app.run(host="127.0.0.1", port=PORT, debug=False)
