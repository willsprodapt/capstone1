import requests
import xml.etree.ElementTree as ET

url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
params = {
    "db": "pubmed",
    "term": "mRNA vaccine respiratory",
    "retmax": 3,
    "retmode": "json"
}
try:
    r = requests.get(url, params=params, timeout=10)
    print("NCBI ESearch status:", r.status_code)
    ids = r.json().get("esearchresult", {}).get("idlist", [])
    print("Sample PMIDs:", ids)
    
    if ids:
        fetch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
        fetch_params = {
            "db": "pubmed",
            "id": ",".join(ids),
            "retmode": "xml"
        }
        fr = requests.get(fetch_url, params=fetch_params, timeout=10)
        print("NCBI EFetch status:", fr.status_code, "Length:", len(fr.text))
        root = ET.fromstring(fr.content)
        articles = root.findall(".//PubmedArticle")
        print(f"Parsed {len(articles)} articles.")
        for a in articles:
            pmid = a.findtext(".//PMID")
            title = a.findtext(".//ArticleTitle")
            print(f"- PMID {pmid}: {title[:80]}...")
except Exception as e:
    print("Error:", e)
