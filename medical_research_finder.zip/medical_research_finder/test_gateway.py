import requests
import json

GATEWAY_URL = "https://keygateway1.arshnivlabs.com"
LEARNER_KEY = "pubatch11"

headers = {
    "Authorization": f"Bearer {LEARNER_KEY}",
    "Content-Type": "application/json",
}

print("Testing Health...")
try:
    h = requests.get(f"{GATEWAY_URL}/v1/health", timeout=15)
    print("Health Status:", h.status_code, h.text)
except Exception as e:
    print("Health failed:", e)

print("\nTesting Chat (no model parameter)...")
try:
    chat = requests.post(
        f"{GATEWAY_URL}/v1/chat/completions",
        headers=headers,
        json={"messages": [{"role": "user", "content": "Respond with 'GATEWAY CHAT WORKING' and nothing else."}]},
        timeout=30,
    )
    print("Chat Status:", chat.status_code)
    print("Chat Response:", chat.text)
except Exception as e:
    print("Chat failed:", e)

print("\nTesting Embeddings (no model parameter)...")
try:
    emb = requests.post(
        f"{GATEWAY_URL}/v1/embeddings",
        headers=headers,
        json={"input": "Medical research query test"},
        timeout=30,
    )
    print("Emb Status:", emb.status_code)
    data = emb.json()
    if "data" in data and len(data["data"]) > 0:
        vec = data["data"][0]["embedding"]
        print("Embedding dim:", len(vec), "sample:", vec[:3])
    else:
        print("Emb response:", data)
except Exception as e:
    print("Emb failed:", e)
