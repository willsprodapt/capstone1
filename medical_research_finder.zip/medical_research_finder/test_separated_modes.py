import requests
import sys

sys.stdout.reconfigure(encoding="utf-8")

def test_separated():
    print("=" * 60)
    print("TESTING 1: FETCHING RESEARCH PAPERS (Abstract Finder)")
    print("=" * 60)
    r_fetch = requests.post(
        "http://127.0.0.1:5000/api/fetch_papers",
        json={"query": "mRNA vaccines respiratory infections", "top_k": 3},
        timeout=30,
    )
    print("Fetch status:", r_fetch.status_code)
    d_fetch = r_fetch.json()
    papers = d_fetch.get("papers", [])
    print(f"Successfully fetched {len(papers)} papers from 2,000-record knowledge base:")
    for i, p in enumerate(papers):
        print(f"  [{i+1}] PMID: {p['pmid']} | Date: {p['publication_date']} | Title: {p['title'][:65]}...")

    print("\n" + "=" * 60)
    print("TESTING 2: PROMPTING ABOUT WHAT IS IN THE RESEARCH PAPER")
    print("=" * 60)
    if papers:
        target_pmid = papers[0]["pmid"]
        print(f"Selected Target: PMID {target_pmid}")
        user_prompt = "What was the specific clinical trial design and vaccine effectiveness reported in this paper?"
        print(f"User Prompt: '{user_prompt}'\n")

        r_chat = requests.post(
            "http://127.0.0.1:5000/api/chat",
            json={
                "message": user_prompt,
                "selected_pmids": [target_pmid],
                "history": [],
            },
            timeout=30,
        )
        print("Chat status:", r_chat.status_code)
        d_chat = r_chat.json()
        print("\nGrounded Response from Paper:")
        print(d_chat.get("response", ""))
        print("\nGrounding Verification Metrics:")
        g = d_chat.get("grounding", {})
        print(f"  - Grounding Score: {g.get('grounding_score')}")
        print(f"  - Citations Verified: {g.get('citations_verified')}")
        print(f"  - Supported Claims: {round(g.get('supported_claim_rate', 0)*100)}%")
        print(f"  - Source Papers Used: {g.get('source_papers_used')}")
        print(f"  - Verified PMIDs: {g.get('verified_pmids')}")

if __name__ == "__main__":
    test_separated()
