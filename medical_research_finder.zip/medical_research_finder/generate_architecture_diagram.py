import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path

def draw_architecture():
    docs_dir = Path(__file__).resolve().parent / "docs"
    docs_dir.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(16, 11), dpi=300)
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 11)
    ax.axis("off")

    # Title & Subtitle
    plt.text(8, 10.5, "AI-Powered Medical Research Abstract Finder & Grounded RAG Architecture",
             fontsize=18, fontweight="bold", ha="center", color="#0f172a", fontfamily="sans-serif")
    plt.text(8, 10.15, "End-to-End Biomedical Pipeline: Data Ingestion → Deterministic & LLM Validation → Hybrid RRF → Grounded Synthesis",
             fontsize=11, color="#64748b", ha="center", fontfamily="sans-serif")

    # Palette
    c_data = "#e0f2fe"       # Light blue
    c_val = "#fef3c7"        # Amber
    c_index = "#f3e8ff"      # Purple
    c_ret = "#ccfbf1"        # Teal
    c_rag = "#dbeafe"        # Blue
    c_ground = "#dcfce7"     # Green
    c_ui = "#f1f5f9"         # Slate

    def draw_box(x, y, w, h, title, subtitle, bg_color, border_color="#334155", radius=0.2):
        rect = patches.FancyBboxPatch(
            (x, y), w, h,
            boxstyle=f"round,pad={radius},rounding_size=0.15",
            linewidth=1.5, edgecolor=border_color, facecolor=bg_color, zorder=2
        )
        ax.add_patch(rect)
        ax.text(x + w / 2, y + h - 0.35, title, fontsize=11, fontweight="bold", ha="center", va="top", color="#0f172a")
        ax.text(x + w / 2, y + (h - 0.5) / 2, subtitle, fontsize=8.5, ha="center", va="center", color="#334155", multialignment="center")

    def draw_arrow(x1, y1, x2, y2, label=""):
        ax.annotate(
            "", xy=(x2, y2), xytext=(x1, y1),
            arrowprops=dict(arrowstyle="->", color="#475569", lw=2, mutation_scale=15),
            zorder=3
        )
        if label:
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            ax.text(mx, my + 0.15, label, fontsize=8, fontweight="bold", color="#1e293b", ha="center",
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="#ffffff", edgecolor="#cbd5e1", lw=1))

    # Row 1: Data Preparation & Two-Stage Validation
    draw_box(0.5, 7.8, 3.2, 1.6, "1. PubMed Ingestion", "NCBI E-Utilities (2,000 Records)\nFields: PMID, Title, Abstract,\nAuthors, PubDate, MeSH, Keywords", c_data, "#0284c7")
    draw_arrow(4.0, 8.6, 4.6, 8.6, "Raw CSV")

    draw_box(4.8, 7.5, 5.0, 2.2, "2. Two-Stage Dataset Validation Pipeline",
             "Stage A: Deterministic Validation\n• Schema & Digit PMID  • Deduplication\n• Regex Date (1950-2026) • Non-empty Abstract\nStage B: LLM Semantic & Quality Validation\n• Medical Research Content • Date/Trial Inconsistency\n• Flag for review (Zero Fact Modification)", c_val, "#d97706")
    draw_arrow(10.1, 8.6, 10.7, 8.6, "Validated")

    draw_box(11.0, 7.8, 4.4, 1.6, "Validation Output & Dashboard", "• data/validation_results.json\n• Accepted (Clean Corpus) → Indexing\n• Flagged & Rejected with Reasons\n• Data Validation Dashboard UI", c_val, "#d97706")

    # Arrow down from Validation to Indexing
    draw_arrow(13.2, 7.5, 13.2, 6.7, "Clean Data")

    # Row 2: Indexing & Knowledge Base
    draw_box(10.5, 5.0, 5.0, 1.5, "3. Provenance-Preserved Chunking",
             "DocumentChunker:\n• Preserves full abstract & normalized text\n• Chunk ID (e.g. 12345678_01) & Source Doc ID\n• Retains PMID, Title, Date, MeSH", c_index, "#7e22ce")
    draw_arrow(10.2, 5.75, 8.6, 5.75, "Chunks")

    draw_box(4.2, 4.8, 4.2, 1.9, "4. Dual Index Knowledge Base",
             "BM25 Keyword Index\n• BM25Okapi over tokenized text & MeSH\n\nDense Vector Index\n• text-embedding-3-small (1536-dim)\n• Cached embeddings matrix (.npy)", c_index, "#7e22ce")

    # Row 3: Retrieval & Query Flow
    draw_box(0.5, 4.8, 3.2, 1.9, "User Research Query", "Natural Language Query\n• e.g. 'mRNA vaccines against respiratory infections'\n• Metadata Filters: Year, MeSH, Author\n• Retrieval Mode Selection", c_ui, "#0f172a")
    draw_arrow(4.0, 5.75, 4.2, 5.75, "Query")

    # Arrow down from Dual Index to Retrieval Fusion
    draw_arrow(6.3, 4.5, 6.3, 3.8, "BM25 & Vector Scores")

    # Row 4: Hybrid RRF & Reranking
    draw_box(3.5, 2.1, 5.6, 1.5, "5. Hybrid RRF & Reranking Engine",
             "Reciprocal Rank Fusion: RRF = 1/(60 + r_BM25) + 1/(60 + r_Dense)\nFeature Reranker: RRF + Semantic Cosine + Title Match + MeSH Overlap\nFallback Cascade: Hybrid → Dense-Only → BM25-Only\nDeduplication & Provenance Alignment", c_ret, "#0f766e")
    draw_arrow(9.3, 2.85, 9.9, 2.85, "Top-K Papers")

    # Row 5: RAG Synthesis & Grounding
    draw_box(10.1, 1.8, 5.4, 2.2, "6. Grounded RAG Synthesizer & LLM",
             "Structured Context Construction:\n[DOCUMENT 1..K] PMID, Title, Date, Abstract, MeSH\n\nStrict System Prompt:\n• Answer ONLY from retrieved research evidence\n• Zero pretrained knowledge / No hallucination\n• Mandatory PMID citations: [PMID: <pmid>]\n• Structured: Summary, Findings, Evidence, Comparison, Limitations", c_rag, "#1d4ed8")

    # Arrow down from RAG to Grounding Verification
    draw_arrow(12.8, 1.5, 12.8, 0.9, "Synthesized Answer")

    draw_box(7.5, -0.6, 8.0, 1.3, "7. Grounding & Citation Verification Engine",
             "• Claim Extraction  • Citation Extraction ([PMID:...])  • Context & KB Verification\n• Semantic Alignment Scoring  • Grounding Score (0-1.0)  • Flag Unsupported Claims", c_ground, "#16a34a")

    # User Application UI box
    draw_box(0.5, 0.2, 6.2, 2.0, "8. User Application & Dashboards (Flask)",
             "• Search & RAG Synthesizer UI: Clickable PMIDs, Grounding Badges\n• Data Validation Dashboard: Accepted, Flagged, Rejected Inspection\n• Evaluation Dashboard: Recall@K, Precision@5, MRR, nDCG@10, Citation Validity\n• REST API: /api/search, /api/validation, /api/evaluation, /api/paper/<pmid>", c_ui, "#0f172a")

    draw_arrow(7.2, 0.1, 7.0, 0.6, "Verified Response")

    plt.tight_layout()
    png_path = docs_dir / "architecture_diagram.png"
    pdf_path = docs_dir / "architecture_diagram.pdf"
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(pdf_path, bbox_inches="tight")
    plt.close()
    print(f"Architecture diagram saved to {png_path} and {pdf_path}")

if __name__ == "__main__":
    draw_architecture()
