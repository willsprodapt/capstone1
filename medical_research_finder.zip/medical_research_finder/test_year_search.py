import requests

url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
years = [2020, 2021, 2022, 2023, 2024, 2025]
for y in years:
    term = f'(mRNA vaccine OR diabetes cardiovascular OR cancer immunotherapy) AND ("{y}/01/01"[Date - Publication] : "{y}/12/31"[Date - Publication])'
    params = {"db": "pubmed", "term": term, "retmax": 3, "retmode": "json"}
    r = requests.get(url, params=params, timeout=10)
    if r.status_code == 200:
        ids = r.json().get("esearchresult", {}).get("idlist", [])
        count = r.json().get("esearchresult", {}).get("count", 0)
        print(f"Year {y}: found {count} papers, sample IDs: {ids[:2]}")
